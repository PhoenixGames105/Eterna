module.exports = {
    name: "automodsettings",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        const fs = require('fs');
        const Discord = require('discord.js')
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }
        

      var guildid = msg.guild.id;
      
      readJson(`../settings/${guildid}.json`, (err, guildsettings) => {
        var mod = guildsettings.automod
        var endisa
        var endisa2
        var endisa3
        var endisa4
        var endisa5
        var endisa6
        if(!mod){
          endisa = "disabled"
          endisa2 = "disabled"
          endisa3 = "disabled"
          endisa4 = "disabled"
          endisa5 = "disabled"
          endisa6 = "disabled"
        }else{
          endisa = mod[0]
          endisa2 = mod[1]
          endisa3 = mod[2]
          endisa4 = mod[3]
          endisa5 = mod[4]
          endisa6 = mod[5]
        }

        if(msg.member.hasPermission('ADMINISTRATOR')){
var guildid = msg.guild.id;
readJson(`../settings/${guildid}.json`, (err, guildsettings) => {
var prefix = guildsettings.prefix
var settingpage = new Discord.RichEmbed()
.setColor(0xFF0000)
.setTitle(`Your server's AutoMod settings (${prefix}automod {settings} {value})`)
.addField(`AutoMod(${prefix}settings{enable/disable}automod):` , endisa)
.addField(`Warn Threshold(warnat): `, endisa2)
.addField(`Ban Threshold(banat): `, endisa3)
.addField(`Max Time Interval(msgtime): `, endisa4 + "ms")
.addField(`Max Duplicates Warning(maxdupwarn): `, endisa5)
.addField(`Max Duplicates Ban(maxdupban): `, endisa6)
.setThumbnail(msg.guild.iconURL)
msg.channel.send(settingpage);
return;
})
    }else{
    msg.reply('You dont have perms.')}
    })
}
}