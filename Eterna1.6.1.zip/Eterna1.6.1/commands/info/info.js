module.exports = {
    name: "info",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const Discord = require('discord.js')
        var version = '1.6.1 | Released 10/25/19 @ 8:42pm';
        var infotable = new Discord.RichEmbed()
        .setColor(0xFF0000)
        .setTitle(`Eterna Info`)
        .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
        .addField(`Version`, version)
        .addField('Invite me to your server!', "https://discordapp.com/oauth2/authorize?client_id=607007761947033601&scope=bot&permissions=8")
        .addField('Join the EternaBot Development discord!', 'https://discord.gg/SxUVCzn')


        
            msg.channel.send(infotable);
            return;
        
    }}