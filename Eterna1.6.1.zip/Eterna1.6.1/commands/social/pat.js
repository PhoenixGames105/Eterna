module.exports = {
    name: "pat",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        var user = msg.mentions.members.first()
        if (args.length < 1){
            msg.reply("Pat who?");
            return;
            }else{
        if (user){

        var clid = client.user.id
        if (user.id === clid){return}

        

            if (user.id == msg.author.id){
                msg.reply('Pat pat!')
                return;
            }
        const sender = msg.author.username;
        const rekt = user;
        msg.channel.send(`${rekt} is patted by ${sender}`);
        
    }else{msg.reply('User is not in the server')}}

    }
}