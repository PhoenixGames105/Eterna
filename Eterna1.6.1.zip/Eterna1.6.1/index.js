const {Client, RichEmbed, Collection } = require("discord.js");
const token = "";
const client = new Client({

});
var fs = require('fs');

const DiscordAntiSpam = require("discord-anti-spam");

client.commands = new Collection();
client.aliases = new Collection();

["command"].forEach(handler => {
    require(`./handler/${handler}`)(client);
    
})



client.login(token);

client.on('ready', () =>{
    
const clientid = (client.user.username);
    console.log(`<<${clientid} ONLINE>>`);
    client.user.setActivity(`for a mention`, {type: 'WATCHING'});
})

client.on("message", async msg =>{
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }


      
      


    var mention = msg.mentions.users.first()
if (msg.content.startsWith(client.user + "reset")){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    msg.reply("Server settings file updating..");
    setTimeout(settingsReset, 1000);
    function settingsReset(){
    var admin = msg.author.username; 
    var config = {
        changedby: admin,
        profanity: "enabled",
        kill: "enabled",
        prefix: "e.",
        chatbot: "disabled",
        level: "enabled",
        automod: ["disabled", 3, 7, 2000, 7, 15]
    };
        

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
        });
    }}else{if (msg.member.id === "184844321919467520"){
        msg.reply("Server settings file updating..");
        setTimeout(settingsReset, 1000);
        function settingsReset(){
        var admin = msg.author.username; 
        var config = {
            changedby: admin,
            profanity: "enabled",
            kill: "enabled",
            prefix: "e.",
            chatbot: "disabled",
            level: "enabled",
            automod: ["disabled", 3, 7, 2000, 7, 15]
        };
            
    
            fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("File has been created");
            });
        }

        }else{
        msg.reply('You dont have perms.');
    }}
}
var guildid = msg.guild.id;
//chatbot block=================================================================================================
readJson(`./commands/settings/${guildid}`, (err, guildsettings) => {
if (guildsettings.chatbot === "enabled"){
if (msg.content.includes("gay")){msg.channel.send('No you')}
if(msg.content.endsWith('?')){
    let hmm = Math.floor(Math.random() * 8);
    if (hmm === 3){msg.channel.send('Bro thats kinda a messed up thing to ask smh.')}
    if (hmm === 7){msg.channel.send('hmm...')}
}
if (msg.content.includes('retard')){msg.channel.send('What a clown :clown: ^^^')}
if (msg.content.includes('nigga')){msg.channel.send(`"I'm cool because i say the N word":clown:`)}
if (msg.content.includes('nigger')){msg.channel.send(`Raging racist ^^^ :clown:`)}
}})

//end chatbot block==============================================================================================
readJson(`./commands/settings/${guildid}`, (err, prfx) => {
    var guildid = msg.guild.id
    const PREFIX = prfx.prefix;
    var mention = msg.mentions.users.first()

    if(mention === client.user){msg.reply(`Forgot the prefix? it's ${PREFIX}`)}
 
    if (msg.author.id === client.user.id) return;
    if (!msg.guild) return;
    if (!msg.content.startsWith(PREFIX)) return;
    if (!msg.member) msg.member = msg.guild.fetchMember(msg);

   const args = msg.content.slice(PREFIX.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();

    if (cmd.length === 0) return;




    
    //settings block---------------------------------------------------------------------------------
    readJson(`./commands/settings/${guildid}`, (err, curset) => {
var guildid = msg.guild.id;
    if(cmd === 'settingsreset'){
        if(msg.member.hasPermission('ADMINISTRATOR')){
        msg.reply("Server settings file updating..");
        setTimeout(settingsReset, 1000);
        function settingsReset(){
        var admin = msg.author.username; 
            var config = {
                changedby: admin,
                profanity: "enabled",
                kill: "enabled",
                prefix: "e.",
                chatbot: "disabled",
                level: "enabled",
                automod: ["disabled", 3, 7, 2000, 7, 15]
            };
            

            fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("File has been created");
                
        msg.reply("Server settings file updated.");
            });
        }}else{
            msg.reply('You dont have perms.');
        }
    }
    switch(cmd)
    {
        case ('disable'):
            {
                switch(args[0])
            {
                case('profanity'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill
                    var admin = msg.author.username;
                    var pref = curset.prefix
                    var chatbot = curset.chatbot
                    var level = curset.level
                    var automod = curset.automod
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: "disabled",
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
            
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
            
                }}else{
                    msg.reply('You dont have perms.');
                }

                
                break;}
                case('kill'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var profena = curset.profanity
                    var admin = msg.author.username;
                    var pref = curset.prefix
                    var chatbot = curset.chatbot
                    var level = curset.level
                    var automod = curset.automod
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: profena,
                        kill: "disabled",
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
            
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
            
                }}else{
                    msg.reply("You dont have perms.");
                }

                
                break;}
                case('chatbot'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = "disabled";
                    var pref = curset.prefix;
                    var level = curset.level
                    var automod = curset.automod
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }

                
                break;}
                case('level'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = "disabled"
                    var automod = curset.automod
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
                    
                
                break;}
                case('automod'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                    var automod = ["disabled", 3, 7, 2000, 7, 15]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
                    
                
                break;}
            }
                break;
            }
        case ('enable'):
            {
                switch(args[0])
                {
                    case('profanity'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill
                        var admin = msg.author.username;
                        var pref = curset.prefix
                        var chatbot = curset.chatbot
                        var level = curset.level
                        var automod = curset.automod
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: "enabled",
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                    break;
                    }
                    case('kill'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var profena = curset.profanity
                        var admin = msg.author.username;
                        var pref = curset.prefix
                        var chatbot = curset.chatbot
                        var level = curset.level
                        var automod = curset.automod
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: profena,
                            kill: "enabled",
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply("You dont have perms.");
                    }
                        
                    
                
                
                    break;}
                    case('chatbot'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill;
                        var botprof = curset.profanity;
                        var admin = msg.author.username;
                        var chatbot = "enabled";
                        var pref = curset.prefix;
                        var level = curset.level
                        var automod = curset.automod
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: botprof,
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                        
                    
                    break;}
                    case('level'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill;
                        var botprof = curset.profanity;
                        var admin = msg.author.username;
                        var chatbot = curset.chatbot;
                        var pref = curset.prefix;
                        var level = "enabled"
                        var automod = curset.automod
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: botprof,
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                        
                    
                    break;}
                    case('automod'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill;
                        var botprof = curset.profanity;
                        var admin = msg.author.username;
                        var chatbot = curset.chatbot;
                        var pref = curset.prefix;
                        var level = curset.level
                        var automod = ["enabled", 3, 7, 2000, 7, 15]
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: botprof,
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                        
                    
                    break;}
                }
               break; 
            }
        default:
            return;
    }
    if(cmd === 'prefix'){
    if(msg.member.hasPermission('ADMINISTRATOR')){
        if(args < 1){msg.reply('Choose a prefix!')
    return;};
    var killena = curset.kill;
    var botprof = curset.profanity;
    var admin = msg.author.username;
    var chatbot = curset.chatbot
    var pref = args[0];
    var level = curset.level
    var automod = curset.automod
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: botprof,
        kill: killena,
        prefix: pref,
        chatbot: chatbot,
        level: level,
        automod: automod
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply('You dont have perms.');
}
    }
//mod settings =================================================================================================
if(msg.member.hasPermission('ADMINISTRATOR')){
if(cmd === 'automod'){
    switch(args[0])
    {
        case ('warnat'):
            var arg2 = args[1]
                if(msg.member.hasPermission('ADMINISTRATOR')){
                var killena = curset.kill;
                var botprof = curset.profanity;
                var admin = msg.author.username;
                var chatbot = curset.chatbot;
                var pref = curset.prefix;
                var level = curset.level
                var warnat = arg2
                var banat = curset.automod[2]
                var time = curset.automod[3]
                var maxdupwarn = curset.automod[4]
                var maxdupban = curset.automod[5]
                var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                msg.reply("Server settings file updating..");
                setTimeout(botProfanity, 1000); 
                function botProfanity(){
                var config = {
                    changedby: admin,
                    profanity: botprof,
                    kill: killena,
                    prefix: pref,
                    chatbot: chatbot,
                    level: level,
                    automod: automod
                };
            
                fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                    if (err) {
                        console.error(err);
                        return;
                    };
                    console.log("File has been created");
                    msg.reply("Server settings file updated!");
                });
            
            }}else{
                msg.reply('You dont have perms.');
            }
            
            break;
        case ('banat'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = arg2
                    var time = curset.automod[3]
                    var maxdupwarn = curset.automod[4]
                    var maxdupban = curset.automod[5]
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        case ('msgtime'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = curset.automod[2]
                    var time = arg2
                    var maxdupwarn = curset.automod[4]
                    var maxdupban = curset.automod[5]
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        case ('maxdupwarn'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = curset.automod[2]
                    var time = curset.automod[3]
                    var maxdupwarn = arg2
                    var maxdupban = curset.automod[5]
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        case ('maxdupban'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = curset.automod[2]
                    var time = curset.automod[3]
                    var maxdupwarn = curset.automod[4]
                    var maxdupban = arg2
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        default:
            msg.reply("Please enter a setting to change.")
        
    }

    }
}else{
    msg.reply("You dont have perms.")
}
    


//end mod settings =============================================================================================
    
})
//end settings block------------------------------------------------------------------------------------


   
    let command = client.commands.get(cmd);
    if (!command) command = client.commands.get(client.aliases.get(cmd));

    if (command)
        command.run(client, msg, args);
}) 
//xp block=======================================================================================================


readJson(`./commands/settings/${guildid}.json`, (err, curset) => {
if (curset.level === 'enabled'){
if (msg){
    if (msg.author.id === client.user.id)return;
    var user = msg.author.id;
    //if xp file doesnt exist, make one========================================
        path = `./commands/usersXP/${user}.json`
        fs.access(path, fs.F_OK, (err) => {
            if (err) {
              console.error(err)
                var userXp = {
                xp: [1,1]
                }
    
    
                fs.writeFile(`./commands/usersXP/${user}.json`, JSON.stringify(userXp, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("Xp file has been created");
                });
              return
            }
            //===============================================================
            //file exists: read it and increase xp by 1
            readJson(`./commands/usersXP/${user}.json`, (err, userxpdata) => {
                var xp = userxpdata.xp[0];
                var lvl = userxpdata.xp[1];
                xp++;
                if(xp === (lvl * 5)){
                    lvl++;
                    msg.channel.send(`Congrats ${msg.author.username}! you've reached lvl ${lvl}!`);
                    var userXp = {
                        xp: [0,lvl]
                        }
            
            
                        fs.writeFile(`./commands/usersXP/${user}.json`, JSON.stringify(userXp, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        });
                      return
                }else{
                    var userXp = {
                        xp: [xp,lvl]
                        }
            
            
                        fs.writeFile(`./commands/usersXP/${user}.json`, JSON.stringify(userXp, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        });
                      return
                }

            
          })

})
}
}
})
//end xp block==================================================================================================
//Automod block=================================================================================================


readJson(`./commands/settings/${guildid}.json`, (err, curset) => {
    if(!curset.automod)return;
if(curset.automod[0] === "enabled"){
    var mod = curset.automod
        
    var AntiSpam = new DiscordAntiSpam({
        warnThreshold: mod[1], // Amount of messages sent in a row that will cause a warning.
        banThreshold: mod[2], // Amount of messages sent in a row that will cause a ban
        maxInterval: mod[3], // Amount of time (in ms) in which messages are cosidered spam.
        warnMessage: "{@user}, Please stop spamming.", // Message will be sent in chat upon warning.
        banMessage: "**{user_tag}** has been banned for spamming.", // Message will be sent in chat upon banning.
        maxDuplicatesWarning: mod[4], // Amount of same messages sent that will be considered as duplicates that will cause a warning.
        maxDuplicatesBan: mod[5], // Amount of same messages sent that will be considered as duplicates that will cause a ban.
        deleteMessagesAfterBanForPastDays: 1, // Amount of days in which old messages will be deleted. (1-7)
        exemptPermissions: ["MANAGE_MESSAGES", "ADMINISTRATOR", "MANAGE_GUILD", "BAN_MEMBERS"], // Bypass users with at least one of these permissions
        ignoreBots: true, // Ignore bot messages
        verbose: true, // Extended Logs from module
        ignoredUsers: [], // Array of string user IDs that are ignored
        ignoredGuilds: [], // Array of string Guild IDs that are ignored
        ignoredChannels: [] // Array of string channels IDs that are ignored
      });
      AntiSpam.on("warnEmit", (member) => console.log(`Attempt to warn ${member.user.tag}.`));
      AntiSpam.on("warnAdd", (member) => console.log(`${member.user.tag} has been warned.`));
      AntiSpam.on("kickEmit", (member) => console.log(`Attempt to kick ${member.user.tag}.`));
      AntiSpam.on("kickAdd", (member) => console.log(`${member.user.tag} has been kicked.`));
      AntiSpam.on("banEmit", (member) => console.log(`Attempt to ban ${member.user.tag}.`));
      AntiSpam.on("banAdd", (member) => console.log(`${member.user.tag} has been banned.`));
      AntiSpam.on("dataReset", () => console.log("Module cache has been cleared."));
      AntiSpam.message(msg);
    }else{return}


})
})





client.on("guildCreate", guild => {
    console.log("Joined a new guild: " + guild.name);
    var guildid = guild.id;
    var admin = guild.owner.username; 
        var config = {
            changedby: admin,
            profanity: "enabled",
            kill: "enabled",
            prefix: "e."
        };
        

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
        });

})



client.on('guildMemberAdd', member =>{
            
    const channel = member.guild.channels.find(channel => channel.name === "welcome");
    if(!channel) return;
    let randomJoinMsg = Math.floor(Math.random() * 4);

    switch(randomJoinMsg){
        case(0):
        channel.send(`Welcome to literal garbage, ${member}, please don't be retarded.`);
        break
        case(1):
        channel.send(`This is a guild, ${member}, you're in it now.`);
        break
        case(2):
        channel.send(`Hi, ${member}, this is a place for not stupid people. Prove your worth.`);
        break
        case(3):
        channel.send(`Who let ${member} in? I thought they were banned...`);
        break
    };

});