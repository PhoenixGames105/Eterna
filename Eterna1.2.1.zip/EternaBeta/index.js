const {Client, RichEmbed, Collection } = require("discord.js");
const token = "";
const client = new Client({
});
const PREFIX = 'e.';

client.commands = new Collection();
client.aliases = new Collection();

["command"].forEach(handler => {
    require(`./handler/${handler}`)(client);
    
})

client.login(token);

client.on('ready', () =>{
    
const clientid = (client.user.username);
    console.log(`<<${clientid} ONLINE>>`);
    client.user.setActivity(`for an ${PREFIX}`, {type: 'WATCHING'});
})

client.on("message", async msg =>{
    
    if (msg.author.bot) return;
    if (!msg.guild) return;
    if (!msg.content.startsWith(PREFIX)) return;
    if (!msg.member) msg.member = await msg.guild.fetchMember(msg);

   const args = msg.content.slice(PREFIX.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();

    if (cmd.length === 0) return;

    let command = client.commands.get(cmd);
    if (!command) command = client.commands.get(client.aliases.get(cmd));

    if (command)
        command.run(client, msg, args);

})


client.on('guildMemberAdd', member =>{
            
    const channel = member.guild.channels.find(channel => channel.name === "welcome");
    if(!channel) return;
    let randomJoinMsg = Math.floor(Math.random() * 4);

    switch(randomJoinMsg){
        case(0):
        channel.send(`Welcome to literal garbage, ${member}, please don't be retarded.`);
        break
        case(1):
        channel.send(`This is a guild, ${member}, you're in it now.`);
        break
        case(2):
        channel.send(`Hi, ${member}, this is a place for not stupid people. Prove your worth.`);
        break
        case(3):
        channel.send(`Who let ${member} in? I thought they were banned...`);
        break
    };
  
});





