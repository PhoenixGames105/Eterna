module.exports = {
    name: "why",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        let randomWhy = Math.floor(Math.random() * 8)
        switch(randomWhy){
            case(0):
                msg.reply('They deserve it.');
            break;
            case(1):
                msg.reply('dunno tbh.')
            break
            case(2):
                msg.reply('seems kinda gay to me..')
            break
            case(3):
                msg.reply('idk but i really dont like you asking me.')
            break
            case(4):
                msg.reply('youre stupid please stop asking.')
            break
            case(5):
                msg.reply('its stupid asf')
            break
            case(6):
                msg.reply('why the fuck not??')
            break
            case(7):
                msg.reply('because God allows it.')
            break;
    }
    }}