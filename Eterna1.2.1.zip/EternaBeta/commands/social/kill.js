module.exports = {
    name: "kill",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        if (args.length < 1){
        msg.reply("who is dying?");
        }else{
            let randomKill = Math.floor(Math.random() * 8)
        const sender = msg.author.username;
        const rekt = msg.mentions.users.first();
        switch(randomKill){
            case(0):
            msg.channel.send(`${rekt} gets fucking demolished by ${sender}`);
            break;
            case(1):
            msg.channel.send(`${sender} kicks the stool out from under ${rekt}`);
            break;
            case(2):
            msg.channel.send(`${rekt} gets blue shelled by ${sender}`);
            break;
            case(3):
            msg.channel.send(`${sender} shoves a crystal up ${rekt}'s ass`);
            break;
            case(4):
            msg.channel.send(`${rekt} is killed by ${sender} in a drive by`);
            break;
            case(5):
            msg.channel.send(`${rekt} was given cyanide laced drugs by ${sender}`);
            break;
            case(6):
            msg.channel.send(`${rekt} obtains 28 stab wounds from ${sender}`);
            break;
            case(7):
            msg.channel.send(`${rekt} is thrown to a pack of rabid chipmunks by ${sender}`);
            break;

        }
        }
    }}