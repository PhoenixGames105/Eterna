module.exports = {
    name: "info",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        
var version = '1.2.1 | Released 9/5/19 @ 10:21pm';
            msg.channel.send('<<ETERNA ONLINE>>');
            msg.channel.send('<<Version ' + version + '>>');
        
    }}