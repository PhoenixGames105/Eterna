module.exports = {
    name: "help",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const PREFIX = 'e.';
const Discord = require("discord.js");
const helppage = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle(`Help Page (Prefix is ${PREFIX})`)
            .addField('ping', 'pong! (requires admin or kick member perms)')
            .addField('website', 'Displays my domain.')
            .addField('kick', 'Kicks misbehaving users (requires admin or kick member perms)')
            .addField('ban', 'Bans bad people (requires admin or kick member perms)')
            .addField('purge', 'Deletes messages in bulk (requires admin or kick member perms)')
            .addField('playerinfo', 'Displays your user info')
            .addField('info', 'Displays Eterna\'s basic info')
            .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')

            msg.channel.send(helppage);
    }}