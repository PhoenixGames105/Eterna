module.exports = {
    name: "purge",
    category: "moderation",
    description: "does a thing",
    run: async (client, msg, args) => {

if(msg.member.hasPermission('ADMINISTRATOR')){
    if(args.length < 1) return msg.reply('Please input amount of messages to brutally dismember!')
    msg.channel.bulkDelete(args[0]);    
    }
    else{

        if(msg.member.hasPermission('MANAGE_MESSAGES')){
            if(!args.length < 1) return msg.reply('Please input amount of messages to brutally dismember!')
            msg.channel.bulkDelete(args[0]);
       }
        else{
           return msg.channel.send('You dont have perms')
           .then(msg => msg.delete(3000)); 
        }}

    }}