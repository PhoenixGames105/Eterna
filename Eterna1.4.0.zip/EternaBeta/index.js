const {Client, RichEmbed, Collection } = require("discord.js");
const token = "";
const client = new Client({

});
var fs = require('fs');

client.commands = new Collection();
client.aliases = new Collection();

["command"].forEach(handler => {
    require(`./handler/${handler}`)(client);
    
})



client.login(token);

client.on('ready', () =>{
    
const clientid = (client.user.username);
    console.log(`<<${clientid} ONLINE>>`);
    client.user.setActivity(`for a mention`, {type: 'WATCHING'});
})

client.on("message", async msg =>{
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }
      



    var mention = msg.mentions.users.first()
if (msg.content.startsWith(client.user + "reset")){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    msg.reply("Server settings file updating..");
    setTimeout(settingsReset, 1000);
    function settingsReset(){
    var admin = msg.author.username; 
        var config = {
            changedby: admin,
            profanity: "enabled",
            kill: "enabled",
            prefix: "e.",
            chatbot: "disabled"
        }
        

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
        });
    }}else{if (msg.member.id === "184844321919467520"){
        msg.reply("Server settings file updating..");
        setTimeout(settingsReset, 1000);
        function settingsReset(){
        var admin = msg.author.username; 
            var config = {
                changedby: admin,
                profanity: "enabled",
                kill: "enabled",
                prefix: "e.",
                chatbot: "disabled"
            }
            
    
            fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("File has been created");
            });
        }

        }else{
        msg.reply('You dont have perms.');
    }}
}
var guildid = msg.guild.id;
//chatbot block=================================================================================================
readJson(`./commands/settings/${guildid}`, (err, guildsettings) => {
if (guildsettings.chatbot === "enabled"){
if (msg.content.includes("gay")){msg.channel.send('No you')}
if(msg.content.endsWith('?')){
    let hmm = Math.floor(Math.random() * 8);
    if (hmm === 3){msg.channel.send('Bro thats kinda a messed up thing to ask smh.')}
    if (hmm === 7){msg.channel.send('hmm...')}
}
if (msg.content.includes('retard')){msg.channel.send('What a clown :clown: ^^^')}
if (msg.content.includes('nigga')){msg.channel.send(`"I'm cool because i say the N word":clown:`)}
if (msg.content.includes('nigger')){msg.channel.send(`Raging racist ^^^ :clown:`)}
}})

//end chatbot block==============================================================================================
readJson(`./commands/settings/${guildid}`, (err, prfx) => {
    var guildid = msg.guild.id
    const PREFIX = prfx.prefix;
    var mention = msg.mentions.users.first()

    if(mention === client.user){msg.reply(`Forgot the prefix? it's ${PREFIX}`)}
 
    if (msg.author.id === client.user.id) return;
    if (!msg.guild) return;
    if (!msg.content.startsWith(PREFIX)) return;
    if (!msg.member) msg.member = msg.guild.fetchMember(msg);

   const args = msg.content.slice(PREFIX.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();

    if (cmd.length === 0) return;




    
    //settings block---------------------------------------------------------------------------------
    readJson(`./commands/settings/${guildid}`, (err, curset) => {
var guildid = msg.guild.id;
    if(cmd === 'settingsreset'){
        if(msg.member.hasPermission('ADMINISTRATOR')){
        msg.reply("Server settings file updating..");
        setTimeout(settingsReset, 1000);
        function settingsReset(){
        var admin = msg.author.username; 
            var config = {
                changedby: admin,
                profanity: "enabled",
                kill: "enabled",
                prefix: "e.",
                chatbot: "disabled"
            };
            

            fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("File has been created");
            });
        }}else{
            msg.reply('You dont have perms.');
        }
    }
    if(cmd === 'settingsdisableprofanity'){
        if(msg.member.hasPermission('ADMINISTRATOR')){
        var killena = curset.kill
        var admin = msg.author.username;
        var pref = curset.prefix
        var chatbot = curset.chatbot
        msg.reply("Server settings file updating..");
        setTimeout(botProfanity, 1000); 
        function botProfanity(){
        var config = {
            changedby: admin,
            profanity: "disabled",
            kill: killena,
            prefix: pref,
            chatbot: chatbot
        };

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
            msg.reply("Server settings file updated!");
        });

    }}else{
        msg.reply('You dont have perms.');
    }
    }
    if(cmd === 'settingsdisablekill'){
        if(msg.member.hasPermission('ADMINISTRATOR')){
        var profena = curset.profanity
        var admin = msg.author.username;
        var pref = curset.prefix
        var chatbot = curset.chatbot
        msg.reply("Server settings file updating..");
        setTimeout(botProfanity, 1000); 
        function botProfanity(){
        var config = {
            changedby: admin,
            profanity: profena,
            kill: "disabled",
            prefix: pref,
            chatbot: chatbot
        };

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
            msg.reply("Server settings file updated!");
        });

    }}else{
        msg.reply("You dont have perms.");
    }
    }
    if(cmd === 'settingsenablekill'){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    var profena = curset.profanity
    var admin = msg.author.username;
    var pref = curset.prefix
    var chatbot = curset.chatbot
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: profena,
        kill: "enabled",
        prefix: pref,
        chatbot: chatbot
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply("You dont have perms.");
}
    }
    if(cmd === 'settingsenableprofanity'){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    var killena = curset.kill
    var admin = msg.author.username;
    var pref = curset.prefix
    var chatbot = curset.chatbot
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: "enabled",
        kill: killena,
        prefix: pref,
        chatbot: chatbot
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply('You dont have perms.');
}
    }
    if(cmd === 'settingsprefix'){
    if(msg.member.hasPermission('ADMINISTRATOR')){
        if(args < 1){msg.reply('Choose a prefix!')
    return;};
    var killena = curset.kill;
    var botprof = curset.profanity;
    var admin = msg.author.username;
    var chatbot = curset.chatbot
    var pref = args[0];
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: botprof,
        kill: killena,
        prefix: pref,
        chatbot: chatbot
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply('You dont have perms.');
}
    }
    if(cmd === 'settingsdisablechatbot'){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    var killena = curset.kill;
    var botprof = curset.profanity;
    var admin = msg.author.username;
    var chatbot = "disabled";
    var pref = curset.prefix;
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: botprof,
        kill: killena,
        prefix: pref,
        chatbot: chatbot
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply('You dont have perms.');
}
    }
    if(cmd === 'settingsenablechatbot'){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    var killena = curset.kill;
    var botprof = curset.profanity;
    var admin = msg.author.username;
    var chatbot = "enabled";
    var pref = curset.prefix;
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: botprof,
        kill: killena,
        prefix: pref,
        chatbot: chatbot
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply('You dont have perms.');
}
    }
})
//end settings block------------------------------------------------------------------------------------



    let command = client.commands.get(cmd);
    if (!command) command = client.commands.get(client.aliases.get(cmd));

    if (command)
        command.run(client, msg, args);
})
})





client.on("guildCreate", guild => {
    console.log("Joined a new guild: " + guild.name);
    var guildid = guild.id;
    var admin = guild.owner.username; 
        var config = {
            changedby: admin,
            profanity: "enabled",
            kill: "enabled",
            prefix: "e."
        };
        

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
        });

})



client.on('guildMemberAdd', member =>{
            
    const channel = member.guild.channels.find(channel => channel.name === "welcome");
    if(!channel) return;
    let randomJoinMsg = Math.floor(Math.random() * 4);

    switch(randomJoinMsg){
        case(0):
        channel.send(`Welcome to literal garbage, ${member}, please don't be retarded.`);
        break
        case(1):
        channel.send(`This is a guild, ${member}, you're in it now.`);
        break
        case(2):
        channel.send(`Hi, ${member}, this is a place for not stupid people. Prove your worth.`);
        break
        case(3):
        channel.send(`Who let ${member} in? I thought they were banned...`);
        break
    };

});