module.exports = {
    name: "settings",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        const fs = require('fs');
        const Discord = require('discord.js')
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }
        
        if(msg.member.hasPermission('ADMINISTRATOR')){
var guildid = msg.guild.id;
readJson(`../settings/${guildid}.json`, (err, guildsettings) => {
var prefix = guildsettings.prefix
var settingpage = new Discord.RichEmbed()
.setColor(0xFF0000)
.setTitle(`Your server settings`)
.addField("Last updated by: ", guildsettings.changedby)
.addField("Bot Profanity: ", guildsettings.profanity)
.addField("Kill command: ", guildsettings.kill)
.addField("Prefix: ", prefix)
.addField("ChatBot: ", guildsettings.chatbot)
.setThumbnail(msg.guild.iconURL)
msg.channel.send(settingpage);
return;
})
    }else{
    msg.reply('You dont have perms.')}

}
}