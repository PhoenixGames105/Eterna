module.exports = {
    name: "kick",
    category: "moderation",
    description: "does a thing",
    run: async (client, msg, args) => {
        if(msg.member.hasPermission('ADMINISTRATOR')){
            if(args.length < 1) return msg.reply('Please tell me who im beating to death.')
    const user = msg.mentions.users.first();

    if(user){
        const member = msg.guild.member(user);

        if(member){
            member.kick('dunno tbh').then(() =>{
                msg.reply(`Kicked ${user.tag}`);
            }).catch(err =>{
                msg.reply('Unable to kick');
                console.log(err);
            });
        } else{
            msg.reply("User is not in this server.")
        }
    }else{
        msg.reply('User is not in the server.')
    }   
            }
            else{

                if(msg.member.hasPermission('KICK_MEMBERS')){
                    if(args.length < 1) return msg.reply('Please tell me who im beating to death.')
    const user = msg.mentions.users.first();

    if(user){
        const member = msg.guild.member(user);

        if(member){
            member.kick('dunno tbh').then(() =>{
                msg.reply(`Kicked ${user.tag}`);
            }).catch(err =>{
                msg.reply('Unable to kick');
                console.log(err);
            });
        } else{
            msg.reply("User is not in this server.")
        }
    }else{
        msg.reply('User is not in the server.')
    }  
               }
                else{
                   return msg.channel.send('You dont have perms')
                   .then(msg => msg.delete(3000)); 
                }}
            }}