module.exports = {
    name: "helpsettings",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const fs = require('fs');
        var guildid = msg.guild.id
        var readJson = (path, cb) => {
            fs.readFile(require.resolve(path), (err, data) => {
              if (err)
                cb(err)
              else
                cb(null, JSON.parse(data))
            })
          }
          readJson(`../settings/${guildid}.json`, (err, guildsettings) => {
        var PREFIX = guildsettings.prefix;
        const Discord = require('discord.js');
        var settingshelp = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(` Settings Help Page (Prefix is ${PREFIX})`)
    .addField(`settings`, `Displays your server's current settings.`)
    .addField(`settingsreset`, `Sets settings back to default.`)
    .addField(`settings{disable/enable}profanity`, `Disables / enables the bot's bad words`)
    .addField(`settings{disable/enable}kill`, `Disables / enables the kill command`)
    .addField(`settingsprefix {value}`, `Sets the Bot's prefix.`)
    .addField(`settings{enable/disable}chatbot`, "Enables/Disables the chatbot responses.")
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')

    msg.channel.send(settingshelp);
    return;
})

    




    }
}