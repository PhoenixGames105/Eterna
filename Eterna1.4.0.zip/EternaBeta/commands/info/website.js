module.exports = {
    name: "website",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const Discord = require("discord.js");
        const website = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .addField('endrv2.tk', 'damn dude thats a domain allright');
            msg.channel.send(website);

}}