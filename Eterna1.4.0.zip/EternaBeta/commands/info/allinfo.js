module.exports = {
    name: "allinfo",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        var guildid = msg.guild.id
        var settings = require(`../settings/${guildid}.json`)
        var prefix = settings.prefix
        if(msg.member.hasPermission('ADMINISTRATOR')){

            msg.channel.send(`${prefix}help all`)
            setTimeout(next2, 2000);
            function next2(){
            msg.channel.send(`${prefix}info`)}
            setTimeout(next, 2000);
            function next(){
            msg.channel.send(`${prefix}helpsettings`)}
            setTimeout(next3, 2000);
            function next3(){
            msg.channel.send(`${prefix}settings`)}
        }else{msg.reply('You dont have perms.')}
    }
}