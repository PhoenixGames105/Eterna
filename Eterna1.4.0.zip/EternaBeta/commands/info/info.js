module.exports = {
    name: "info",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const Discord = require('discord.js')
        var version = '1.4.0 | Released 9/24/19 @ 12:20am';
        var infotable = new Discord.RichEmbed()
        .setColor(0xFF0000)
        .setTitle(`Eterna Info`)
        .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
        .addField(`Version`, version)
        .addField('Invite me to your server!', "shorturl.at/EOW23")
        .addField('Join the EternaBot Development discord!', 'https://discord.gg/SxUVCzn')


        
            msg.channel.send(infotable);
            return;
        
    }}