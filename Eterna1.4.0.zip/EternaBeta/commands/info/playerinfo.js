module.exports = {
    name: "playerinfo",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const Discord = require("discord.js");
const playerinfo = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setThumbnail(msg.author.avatarURL)
            .setTitle('Player Info')
            .addField('Player Name ', msg.author.username)
            .addField('Current Server', msg.guild.name)
            .addField(`Join date`, msg.guild.joinedAt)
            msg.channel.send(playerinfo);

}}