module.exports = {
    name: "ping",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        //if (cmd === "ping"){
            
const clientid = (client.user.username);
        if(msg.member.hasPermission('ADMINISTRATOR')){//checks for admin perm, if not present, checks for "staff" role. if not present, tells user they dont have perms.
            msg.reply(`Pong!\n ${clientid}'s ping is ${Math.round(client.ping)}ms`);    
            }
            else{

                if(msg.member.hasPermission('KICK_MEMBERS')){
                msg.reply(`Pong!\n ${clientid}'s ping is ${Math.round(client.ping)}ms`);   
               }
                else{
                   return msg.channel.send('You dont have perms')
                   .then(msg => msg.delete(3000)); //deletes msg after 3s
                }}//}
    }
}