const Discord = require('discord.js');
const bot = new Discord.Client();

const Token = 'NjA3MDA3NzYxOTQ3MDMzNjAx.XUXi2A.WzNjCv3MnlgIh47r1ualr9tgmEM';

const PREFIX = '/';

var version = '1.1.0 | Released 10/03/19 @ 3:36pm';



bot.on('ready', () =>{
    console.log('<<ETERNA ONLINE>>');
    bot.user.setActivity('the elderly die', {type: 'WATCHING'});
})

bot.on('guildMemberAdd', member =>{
    const channel = member.guild.channels.find(channel => channel.name === "welcome");
    if(!channel) return;

    channel.send(`Welcome to literal garbage, ${member}, please don't be retarded.`)
});
bot.on('raw', event =>{
    console.log(event);
    const eventName = event.t;
    if(eventName === 'MESSAGE_REACTION_ADD'){
        if(event.d.message_id === '607282118996918283'){
            console.log("erect");
            var reactionChannel = bot.channels.get(event.d.channel_id);
            if(reactionChannel.messages.has(event.d.message_id)){
                return;
            }else{
                reactionChannel.fetchMessage(event.d.message_id).then(msg =>{
                    var msgReaction = msg.reactions.get(event.d.emoji.name + ":" + event.d.emoji.id);
                    var user = bot.users.get(event.d.user_id);
                    bot.emit('messageReactionAdd', msgReaction, user);

                    console.log(msgReaction);

                })
            }

        }

    }else if(eventName === 'MESSAGE_REACTION_REMOVED'){
        if(event.d.message_id === '607282118996918283'){
            console.log("erect");
            var reactionChannel = bot.channels.get(event.d.channel_id);
            if(reactionChannel.messages.has(event.d.message_id)){
                return;
            }else{
                reactionChannel.fetchMessage(event.d.message_id).then(msg =>{
                    var msgReaction = msg.reactions.get(event.d.emoji.name + ":" + event.d.emoji.id);
                    var user = bot.users.get(event.d.user_id);
                    bot.emit('messageReactionRemove', msgReaction, user);

                    console.log(msgReaction);

                })
            }

        }   
    }
});
bot.on('messageReactionAdd', (messageReaction,user) =>{
    var roleName = messageReaction.emoji.name;
    console.log(roleName);
    var role = messageReaction.message.guild.roles.find(role => role.name.toLowerCase() === roleName.toLowerCase());

    if(role){
        var member = messageReaction.message.guild.members.find(member => member.id === user.id);
        if(member){
            member.addRole(role.id);
            console.log("succ")
        }
    }
});
bot.on('messageReactionRemove', (messageReaction, user) => {
    var roleName = messageReaction.emoji.name;
    console.log(roleName);
    var role = messageReaction.message.guild.roles.find(role => role.name.toLowerCase() === roleName.toLowerCase());

    if(role){
        var member = messageReaction.message.guild.members.find(member => member.id === user.id);
        if(member){
            member.removeRole(role.id);
            console.log("succ")
        }
    }
});
bot.on('message', msg=>{
    if(!msg.content.startsWith(PREFIX)) return;
    let args = msg.content.substring(PREFIX.length).split(" ");

    switch (args[0]){
        case 'ping'://users can ping Eterna
            if(msg.member.hasPermission('ADMINISTRATOR')){//checks for admin perm, if not present, checks for "staff" role. if not present, tells user they dont have perms.
            msg.reply('Pong!');    
            }
            else{

                if(msg.member.hasPermission('MANAGE_ROLES')){
                msg.reply('Pong!');   
               }
                else{
                   return msg.channel.send('You dont have perms')
                   .then(msg => msg.delete(3000)); //deletes msg after 3s
                }}

            
            break;

        case 'website'://displays website address
            const website = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .addField('endrv2.tk', 'damn dude thats a domain allright');
            msg.channel.send(website);
            break;

        case 'info'://displays info about Eterna. if no second arg exists, it says invalid args.
            if(args[1] === 'version'){
                msg.channel.send('<<Version ' + version + '>>');
            
            }else{
                if(args[1] === 'status'){
                    msg.channel.send('<<ETERNA ONLINE>>');
                    break;
                }
                else{
                 msg.channel.send('invalid args');
            }}
            break;

        case 'purge'://users can bulk delete messages

                if(msg.member.hasPermission('ADMINISTRATOR')){
                    if(!args[1]) return msg.reply('Please input amount of messages to brutally dismember!')
                    msg.channel.bulkDelete(args[1]);    
                    }
                    else{
        
                        if(msg.member.hasPermission('MANAGE_ROLES')){
                            if(!args[1]) return msg.reply('Please input amount of messages to brutally dismember!')
                            msg.channel.bulkDelete(args[1]);
                       }
                        else{
                           return msg.channel.send('You dont have perms')
                           .then(msg => msg.delete(3000)); 
                        }}
        
                    
                    break;
            //if(!args[1]) return msg.reply('Please input amount of messages to brutally dismember!')
            //msg.channel.bulkDelete(args[1]);
            //break;

        case 'playerinfo'://displays basic user info
            const playerinfo = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setThumbnail(msg.author.avatarURL)
            .setTitle('Player Info')
            .addField('Player Name ', msg.author.username)
            .addField('Current Server', msg.guild.name);
            msg.channel.send(playerinfo);
            break;

        case 'kick'://users with the "admin" or "staff" roles can kick players
                if(msg.member.hasPermission('ADMINISTRATOR')){
                    if(!args[1]) return msg.reply('Please tell me who im beating to death.')
            const user = msg.mentions.users.first();

            if(user){
                const member = msg.guild.member(user);

                if(member){
                    member.kick('dunno tbh').then(() =>{
                        msg.reply(`Kicked ${user.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to kick');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }   
                    }
                    else{
        
                        if(msg.member.hasPermission('MANAGE_ROLES')){
                            if(!args[1]) return msg.reply('Please tell me who im beating to death.')
            const user = msg.mentions.users.first();

            if(user){
                const member = msg.guild.member(user);

                if(member){
                    member.kick('dunno tbh').then(() =>{
                        msg.reply(`Kicked ${user.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to kick');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }  
                       }
                        else{
                           return msg.channel.send('You dont have perms')
                           .then(msg => msg.delete(3000)); 
                        }}
        
                    
                    break;
            
            break;

        case 'ban'://users with the "admin" or "staff" roles can ban players

                if(msg.member.hasPermission('ADMINISTRATOR')){
                    if(!args[1]) return msg.reply('Please tell me who im deleting.')
            const banboi = msg.mentions.users.first();
    
            if(banboi){
                   const member = msg.guild.member(banboi);
    
                if(member){
                    member.ban('dunno tbh').then(() =>{
                        msg.reply(`banned ${banboi.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to ban');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }   
                    }
                    else{
        
                        if(msg.member.hasPermission('MANAGE_ROLES')){
                            if(!args[1]) return msg.reply('Please tell me who im deleting.')
            const banboi = msg.mentions.users.first();
    
            if(banboi){
                   const member = msg.guild.member(banboi);
    
                if(member){
                    member.ban('dunno tbh').then(() =>{
                        msg.reply(`banned ${banboi.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to ban');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }  
                       }
                        else{
                           return msg.channel.send('You dont have perms')
                           .then(msg => msg.delete(3000)); 
                        }}
        
                    
                    break;

            
            break;
        
        case 'help'://displays command info

            const helppage = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle('Help Page (Prefix is /)')
            .addField('ping', 'pong! (requires admin or manage role perms)')
            .addField('website', 'Displays my domain.')
            .addField('kick', 'Kicks misbehaving users (requires admin or manage role perms)')
            .addField('ban', 'Bans bad people (requires admin or manage role perms)')
            .addField('purge', 'Deletes messages in bulk (requires admin or manage role perms)')
            .addField('playerinfo', 'Displays your user info')
            .addField('info version', 'Displays Eterna\'s build version')
            .addField('info status', 'Tells you if Eterna is online. No response = No Eterna!')
            .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')

            msg.channel.send(helppage);
            break;
        case 'why':
            msg.reply('They deserve it.');
            break;


    }

})

bot.login(Token);