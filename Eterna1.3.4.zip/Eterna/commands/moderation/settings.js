module.exports = {
    name: "settings",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        const Discord = require('discord.js')
        if(msg.member.hasPermission('ADMINISTRATOR')){
var guildid = msg.guild.id;
var guildsettings = require(`../settings/${guildid}.json`)
var prefix = guildsettings.prefix
var settingpage = new Discord.RichEmbed()
.setColor(0xFF0000)
.setTitle(`Your server settings`)
.addField("Last updated by: ", guildsettings.changedby)
.addField("Bot Profanity: ", guildsettings.profanity)
.addField("Kill command: ", guildsettings.kill)
.addField("Prefix: ", prefix)
.addField("ChatBot: ", guildsettings.chatbot)
.setThumbnail(msg.guild.iconURL)
msg.channel.send(settingpage);
return;

    }else{
    msg.reply('You dont have perms.')}
}
}