module.exports = {
    name: "help",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        var guildid = msg.guild.id;
        var settings = require(`../settings/${guildid}.json`)
        const PREFIX = settings.prefix;
const Discord = require("discord.js");
if (!args[0]){
const helppage = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(`Help Page (Prefix is ${PREFIX})`)
    .addField('help {2/3}', `displays extra help pages`)
    .addField('playerinfo', 'Displays your user info')
    .addField('info', 'Displays Eterna\'s basic info')
    .addField(`serverinfo`, `Displays basic server information.`)
    //.addField("roles", "Displays all roles in the server.")
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    
    msg.channel.send(helppage);
}else{if (args[0] === '2'){
const helppage2 = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(`Help Page 2 (Prefix is ${PREFIX})`)
    .addField('ping', 'pong! (requires admin or kick member perms)')
    .addField('purge', 'Deletes messages in bulk (requires admin or manage messages perms)')
    .addField('kick', 'Kicks misbehaving users (requires admin or kick member perms)')
    .addField('ban', 'Bans bad people (requires admin or ban member perms)')
    .addField('helpsettings', 'Displays the settings help menu')
    .addField(`allinfo`, `Displays all Eterna menus, including help,info,and server settings. (requires admin)`)
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    
    msg.channel.send(helppage2);
    }else{if (args[0] === '3'){
const helppage3 = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(`Help Page 3 (Prefix is ${PREFIX})`)
    .addField(`why`, `for all your questions lol`)
    .addField(`kill`, `brutally murder anyone you mention!`)
    .addField(`pat`, `Pat people you like!`)
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    

            msg.channel.send(helppage3);    
    }else{if (args[0] === 'all'){
        const helppage3 = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle(`Help Page 3 (Prefix is ${PREFIX})`)
            .addField(`why`, `for all your questions lol`)
            .addField(`kill`, `brutally murder anyone you mention!`)
            .addField(`pat`, `Pat people you like!`)
            .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
            const helppage2 = new Discord.RichEmbed()
                .setColor(0xFF0000)
                .setTitle(`Help Page 2 (Prefix is ${PREFIX})`)
                .addField('ping', 'pong! (requires admin or kick member perms)')
                .addField('purge', 'Deletes messages in bulk (requires admin or manage messages perms)')
                .addField('kick', 'Kicks misbehaving users (requires admin or kick member perms)')
                .addField('ban', 'Bans bad people (requires admin or ban member perms)')
                .addField('helpsettings', 'Displays the settings help menu')
                .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
                const helppage = new Discord.RichEmbed()
                    .setColor(0xFF0000)
                    .setTitle(`Help Page (Prefix is ${PREFIX})`)
                    .addField('help {2/3}', `displays extra help pages`)
                    .addField('playerinfo', 'Displays your user info')
                    .addField('info', 'Displays Eterna\'s basic info')
                    .addField(`serverinfo`, `Displays basic server information.`)
                    //.addField("roles", "Displays all roles in the server.")
                    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
        msg.channel.send(helppage)
        msg.channel.send(helppage2)
        msg.channel.send(helppage3)
        return;
    
    }
}
    }}}}