module.exports = {
    name: "why",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        var guildid = msg.guild.id;
        var settings = require(`../settings/${guildid}.json`);
        let randomWhy = Math.floor(Math.random() * 8)
        if (settings.profanity === 'enabled'){
        switch(randomWhy){
            case(0):
                msg.reply('They deserve it.');
            break;
            case(1):
                msg.reply('dunno tbh.')
            break
            case(2):
                msg.reply('seems kinda gay to me..')
            break
            case(3):
                msg.reply('idk but i really dont like you asking me.')
            break
            case(4):
                msg.reply('youre stupid please stop asking.')
            break
            case(5):
                msg.reply('its stupid asf')
            break
            case(6):
                msg.reply('why the fuck not??')
            break
            case(7):
                msg.reply('because God allows it.')
            break;
    }}else{
        switch(randomWhy){
            case(0):
                msg.reply('They deserve it.');
            break;
            case(1):
                msg.reply('dunno tbh.')
            break
            case(2):
                msg.reply('seems kinda dumb to me..')
            break
            case(3):
                msg.reply('idk but i really dont like you asking me.')
            break
            case(4):
                msg.reply('youre stupid please stop asking.')
            break
            case(5):
                msg.reply('its stupid asf')
            break
            case(6):
                msg.reply('why not??')
            break
            case(7):
                msg.reply('because God allows it.')
            break;
    }

    }
    }}