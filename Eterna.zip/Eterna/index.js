const Discord = require('discord.js');
const bot = new Discord.Client();

const Token = 'NjA3MDA3NzYxOTQ3MDMzNjAx.XUTWIQ.8gQPj31qh7KL6da-ciu9q3WPsNw';

const PREFIX = '/';

var version = '1.0.1 | Released 10/03/19 @ 1:15am';



bot.on('ready', () =>{
    console.log('<<ETERNA ONLINE>>');
    bot.user.setActivity('the elderly die', {type: 'WATCHING'});
})

bot.on('guildMemberAdd', member =>{
    const channel = member.guild.channels.find(channel => channel.name === "welcome");
    if(!channel) return;

    channel.send(`Welcome to literal garbage, ${member}, please don't be retarded.`)
});

bot.on('message', msg=>{
    if(!msg.content.startsWith(PREFIX)) return;
    let args = msg.content.substring(PREFIX.length).split(" ");

    switch (args[0]){
        case 'ping':
            if(msg.member.roles.find(r => r.name === "admin")){
            msg.reply('Pong!');    
            }
            else{

                if(msg.member.roles.find(r => r.name === "staff")){
                msg.reply('Pong!');   
               }
                else{
                   return msg.channel.send('You dont have perms')
                   .then(msg => msg.delete(3000)); 
                }}

            
            break;

        case 'website':
            const website = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .addField('endrv2.tk');
            msg.channel.send(website);
            break;

        case 'info':
            if(args[1] === 'version'){
                msg.channel.send('<<Version ' + version + '>>');
            
            }else{
                if(args[1] === 'status'){
                    msg.channel.send('<<ETERNA ONLINE>>');
                    break;
                }
                else{
                 msg.channel.send('invalid args');
            }}
            break;

        case 'purge':

                if(msg.member.roles.find(r => r.name === "admin")){
                    if(!args[1]) return msg.reply('Please input amount of messages to brutally dismember!')
                    msg.channel.bulkDelete(args[1]);    
                    }
                    else{
        
                        if(msg.member.roles.find(r => r.name === "staff")){
                            if(!args[1]) return msg.reply('Please input amount of messages to brutally dismember!')
                            msg.channel.bulkDelete(args[1]);
                       }
                        else{
                           return msg.channel.send('You dont have perms')
                           .then(msg => msg.delete(3000)); 
                        }}
        
                    
                    break;
            //if(!args[1]) return msg.reply('Please input amount of messages to brutally dismember!')
            //msg.channel.bulkDelete(args[1]);
            //break;

        case 'playerinfo':
            const playerinfo = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setThumbnail(msg.author.avatarURL)
            .setTitle('Player Info')
            .addField('Player Name ', msg.author.username)
            .addField('Current Server', msg.guild.name);
            msg.channel.send(playerinfo);
            break;

        case 'kick':
                if(msg.member.roles.find(r => r.name === "admin")){
                    if(!args[1]) return msg.reply('Please tell me who im beating to death.')
            const user = msg.mentions.users.first();

            if(user){
                const member = msg.guild.member(user);

                if(member){
                    member.kick('dunno tbh').then(() =>{
                        msg.reply(`Kicked ${user.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to kick');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }   
                    }
                    else{
        
                        if(msg.member.roles.find(r => r.name === "staff")){
                            if(!args[1]) return msg.reply('Please tell me who im beating to death.')
            const user = msg.mentions.users.first();

            if(user){
                const member = msg.guild.member(user);

                if(member){
                    member.kick('dunno tbh').then(() =>{
                        msg.reply(`Kicked ${user.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to kick');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }  
                       }
                        else{
                           return msg.channel.send('You dont have perms')
                           .then(msg => msg.delete(3000)); 
                        }}
        
                    
                    break;
            
            break;

        case 'ban':

                if(msg.member.roles.find(r => r.name === "admin")){
                    if(!args[1]) return msg.reply('Please tell me who im deleting.')
            const banboi = msg.mentions.users.first();
    
            if(banboi){
                   const member = msg.guild.member(banboi);
    
                if(member){
                    member.ban('dunno tbh').then(() =>{
                        msg.reply(`banned ${banboi.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to ban');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }   
                    }
                    else{
        
                        if(msg.member.roles.find(r => r.name === "staff")){
                            if(!args[1]) return msg.reply('Please tell me who im deleting.')
            const banboi = msg.mentions.users.first();
    
            if(banboi){
                   const member = msg.guild.member(banboi);
    
                if(member){
                    member.ban('dunno tbh').then(() =>{
                        msg.reply(`banned ${banboi.tag}`);
                    }).catch(err =>{
                        msg.reply('Unable to ban');
                        console.log(err);
                    });
                } else{
                    msg.reply("User is not in this server.")
                }
            }else{
                msg.reply('User is not in the server.')
            }  
                       }
                        else{
                           return msg.channel.send('You dont have perms')
                           .then(msg => msg.delete(3000)); 
                        }}
        
                    
                    break;

            
            break;
        
        case 'help':

            const helppage = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle('Help Page (Prefix is /)')
            .addField('ping', 'pong!')
            .addField('website', 'Displays my domain.')
            .addField('kick', 'Kicks misbehaving users')
            .addField('ban', 'Bans bad people')
            .addField('purge', 'Deletes messages in bulk')
            .addField('playerinfo', 'Displays your user info')
            .addField('info version', 'Displays Eterna\'s build version')
            .addField('info status', 'Tells you if Eterna is online. No response = No Eterna!')
            //.setThumbnail('C:\Users\Phoenix\Desktop\Eterna\eterna (2).jpg')

            msg.channel.send(helppage);
            break;
        case 'why':
            msg.reply('They deserve it.');
            break;


    }

})

bot.login(Token);