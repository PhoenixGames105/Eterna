const {Client, RichEmbed, Collection } = require("discord.js");
const token = "";
const client = new Client({

});
const Discord = require("discord.js");
var fs = require('fs');

const DiscordAntiSpam = require("discord-anti-spam");

client.commands = new Collection();
client.aliases = new Collection();

["command"].forEach(handler => {
    require(`./handler/${handler}`)(client);
    
})



client.login(token);

client.on('ready', () =>{
    
const clientid = (client.user.username);
    console.log(`<<${clientid} ONLINE>>`);
setTimeout(stat1, 1000)
        function stat1(){
            client.user.setActivity(`for a mention`, {type: 'WATCHING'});
        setTimeout(stat2, 15000)
        }   
        function stat2(){
            client.user.setActivity(`the world BURN`, {type: 'WATCHING'});
            setTimeout(stat3, 15000)
        }
        function stat3(){
            client.user.setActivity(`Koven`, {type: 'LISTENING'});
            setTimeout(stat4, 15000)
        }
        function stat4(){
            client.user.setActivity(`with your mom's heart`, {type: 'PLAYING'});
            setTimeout(stat1, 15000)
        }
    
})
client.on('raw', event => {
    if (!['MESSAGE_REACTION_ADD', 'MESSAGE_REACTION_REMOVE'].includes(event.t)) return;
    if(event.d.user_id === client.user.id)return
    //console.log(event)
    var eventName = event.t;
    if(eventName === 'MESSAGE_REACTION_ADD')
    {
            var reactionChannel = client.channels.get(event.d.channel_id)
            if(reactionChannel.messages.has(event.d.message_id))
            return
            else{
                reactionChannel.fetchMessage(event.d.message_id)
                .then(msg => {
                    var msgReaction = msg.reactions.get(event.d.emoji.name + ":" + event.d.emoji.id);
                    var user = client.users.get(event.d.user_id)
                    client.emit('messageReactionAdd', msgReaction, user)
                })
            }
    }   
    if(eventName === 'MESSAGE_REACTION_REMOVE')
    {
            var reactionChannel = client.channels.get(event.d.channel_id)
            if(reactionChannel.messages.has(event.d.message_id))
            return
            else{
                reactionChannel.fetchMessage(event.d.message_id)
                .then(msg => {
                    var msgReaction = msg.reactions.get(event.d.emoji.name + ":" + event.d.emoji.id);
                    var user = client.users.get(event.d.user_id)
                    client.emit('messageReactionAdd', msgReaction, user)
                })
            }
    }   
})
client.on('messageReactionAdd', (messageReaction, user) => {
    
    var member = messageReaction.message.guild.members.find(member => member.id === user.id)
    if(member.id === client.user.id)return
    if(messageReaction.message.guild.members.find(member => member.id === user.id) === client.user.id)return;
    var guildid = messageReaction.message.guild.id
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
    }
    var path = `./commands/rolemsg/${messageReaction.message.id}.json`
    fs.access(path, fs.F_OK, (err) => {
        if (err) {
            return
        }
    readJson(`./commands/rolemsg/${messageReaction.message.id}.json`, (err, selfrole) => {
        if(!selfrole.reaction)return
        if(messageReaction.message.id === selfrole.reaction){
            var member = messageReaction.message.guild.members.find(member => member.id === user.id)
            var Role = messageReaction.message.guild.roles.find(role => role.id === selfrole.role)
            if(!Role)return
            member.addRole(Role)
            return
        }else{return}
    })
})
    readJson(`./commands/settings/${guildid}`, (err, guildsettings) => {
        if(messageReaction.message.id === guildsettings.color){
    var roleName = messageReaction.emoji.name;
    var redRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaRed')
    var orangeRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaOr4nge')
    var yellowRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaYellow')
    var greenRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaGreen')
    var blueRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaBlue')
    var purpleRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaPurple')
    var member = messageReaction.message.guild.members.find(member => member.id === user.id)
    if(member.id === client.user.id)return
        switch(roleName)
        {
            case('❤'):
            member.addRole(redRole)
            break;
            case('📙'):
            member.addRole(orangeRole)
            break;
            case('💛'):
            member.addRole(yellowRole)
            break;
            case('💚'):
            member.addRole(greenRole)
            break;
            case('💙'):
            member.addRole(blueRole)
            break;
            case('💜'):
            member.addRole(purpleRole)
            break;
        }
    
    }
    
})
//new help menu====================================================================================================
readJson(`./commands/settings/${guildid}.json`, (err, curset) => {

    var helpath = `./commands/helppagetemp/${messageReaction.message.id}.json`
    fs.access(helpath, fs.F_OK, (err) => {
        if (err) {
            return
        }
readJson(`./commands/helppagetemp/${messageReaction.message.id}.json`, (err, helpPageM) => {
if(messageReaction.message.author.id === client.user.id){
    var member = messageReaction.message.guild.members.find(member => member.id === user.id)
    if(member.id === helpPageM.id){
    if(member.id === client.user.id)return
    var helpReaction = messageReaction.emoji.name
    var id = helpPageM.id
    var helpPage
    switch(helpReaction)
    {
        case('🏠'):
        {
        messageReaction.remove(member)
        
        var config2 = {
            id: helpPageM.id,
            helpPage: 1
        }
        fs.writeFile(`./commands/helppagetemp/${messageReaction.message.id}.json`, JSON.stringify(config2, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            //console.log("File has been created")
        })
        var helpPage = helpPageM.helpPage
        //console.log(helpPage)
        break;
        }
        case('◀'):
        {
            messageReaction.remove(member)
            var config2 = {
                id: helpPageM.id,
                helpPage: helpPageM.helpPage - 1
            }
            fs.writeFile(`./commands/helppagetemp/${messageReaction.message.id}.json`, JSON.stringify(config2, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                //console.log("File has been created")
            })
            var helpPage = helpPageM.helpPage
            //console.log(helpPage)
            break;
        }
        case('🆗'):
        {
            messageReaction.remove(member)
            fs.unlink(helpath, (err) => {
              if (err) {
                console.error(err)
                return
              }
            
              //file removed
            })
            try{
            messageReaction.message.delete()
            }catch{
                console.error
            }
            break;
        }
        case('▶'):
        {
            messageReaction.remove(member)
            var config2 = {
                id: helpPageM.id,
                helpPage: helpPageM.helpPage + 1
            }
            fs.writeFile(`./commands/helppagetemp/${messageReaction.message.id}.json`, JSON.stringify(config2, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                //console.log("File has been created")
            })
            var helpPage = helpPageM.helpPage
            //console.log(helpPage)
            break;
        }
    }
    setTimeout(display, 250)
    function display(){
    fs.access(helpath, fs.F_OK, (err) => {
        if (err) {
            return
        }
    readJson(`./commands/helppagetemp/${messageReaction.message.id}.json`, (err, helpPageM) => {
    if(helpPageM.helpPage < 1)
    {
        var config2 = {
            id: helpPageM.id,
            helpPage: 1
        }
        fs.writeFile(`./commands/helppagetemp/${messageReaction.message.id}.json`, JSON.stringify(config2, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            //console.log("File has been created")
        })
        var helpPage = helpPageM.helpPage
    }
    if(helpPageM.helpPage > 4)
    {
        var config2 = {
            id: helpPageM.id,
            helpPage: 4
        }
        fs.writeFile(`./commands/helppagetemp/${messageReaction.message.id}.json`, JSON.stringify(config2, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            //console.log("File has been created")
        })
        var helpPage = helpPageM.helpPage
    }
    switch(helpPageM.helpPage)
    {
        case(1):
        {
            var edited = new Discord.RichEmbed()
            .setTitle(`Help Page 1 of 4 (Prefix is ${curset.prefix})`)
            .setColor(0xFF0000)
            .addField('help', `Displays the help menu.`)
            .addField('playerinfo @{user}', 'Displays mentioned user\'s info')
            .addField('info', 'Displays Eterna\'s basic info')
            .addField(`serverinfo`, `Displays basic server information.`)
            .setThumbnail(client.user.avatarURL)
            messageReaction.message.edit(edited)
            break;

        }
        case(2):
        {
            var edited = new Discord.RichEmbed()
                .setColor(0xFF0000)
                .setTitle(`Help Page 2 of 4 (Prefix is ${curset.prefix})`)
                .addField('ping', 'pong! (requires admin or kick member perms)')
                .addField('purge {number}', 'Deletes messages in bulk (requires admin or manage messages perms)')
                .addField('kick @{user}', 'Kicks misbehaving users (requires admin or kick member perms)')
                .addField('ban @{user}', 'Bans bad people (requires admin or ban member perms)')
                .addField('automodsettings', `Displays current automod settings and commands.`)
                .addField('mute {@user} {time} {s/m/h/d}', 'Mutes a user for a specified amount of time. If no time is entered the mute is indefinite')
                .setThumbnail(client.user.avatarURL)
                messageReaction.message.edit(edited)
            break;
        }
        case(3):
        {
            var edited = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle(`Help Page 3 of 4 (Prefix is ${curset.prefix})`)
            .addField(`why`, `for all your questions lol`)
            .addField(`kill @{user}`, `brutally murder anyone you mention!`)
            .addField(`pat @{user}`, `Pat people you like!`)
            .addField(`joinmsg {message}`, `sends a custom message whenever someone joins! (type ${curset.prefix}disable joinmsg to disable.)` )
            .addField('{enable/disable} colorrole', 'Adds some color to your guild! Click the color you want!')
            .setThumbnail(client.user.avatarURL)
            messageReaction.message.edit(edited)
            break;
        }
        case(4):
        {
            var edited = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle(`Help Page 4 of 4 (Prefix is ${curset.prefix})`)
            .addField(`settings`, `Displays your server's current settings.`)
            .addField(`settingsreset`, `Sets settings back to default.`)
            //.addField(`{disable/enable} profanity`, `Disables / enables the bot's bad words`)
            .addField(`{disable/enable} kill`, `Disables / enables the kill command`)
            .addField(`prefix {value}`, `Sets the Bot's prefix.`)
            .addField(`{enable/disable} chatbot`, "Enables/Disables the chatbot responses.")
            .addField(`{enable/disable} level`, "Enables/Disables chat based level ups.")
            .addField(`{enable/disable} automod`, "Enables/Disables AutoMod function.")
            .addField("{enable/disable} autorole {@role}", "Gives user a specified role upon joining the server")
            .addField("selfrole {@role}", "Lets users choose a role via reaction")
            .setThumbnail(client.user.avatarURL)
            messageReaction.message.edit(edited)
            break;
        }
    }
})
    })}
}
}
})
    })

})
 });
 client.on('messageReactionRemove', (messageReaction, user) => {
    var guildid = messageReaction.message.guild.id
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
    }
    path = `./commands/rolemsg/${messageReaction.message.id}.json`
    fs.access(path, fs.F_OK, (err) => {
        if (err) {
            return
        }
    readJson(`./commands/rolemsg/${messageReaction.message.id}.json`, (err, selfrole) => {
        if(messageReaction.message.id === selfrole.reaction){
            var member = messageReaction.message.guild.members.find(member => member.id === user.id)
            var Role = messageReaction.message.guild.roles.find(role => role.id === selfrole.role)
            if(!Role)return
            member.removeRole(Role)
            return
        }else{return}
    })
})
    readJson(`./commands/settings/${guildid}`, (err, guildsettings) => {
        if(messageReaction.message.id === guildsettings.color){
    var roleName = messageReaction.emoji.name;
    var redRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaRed')
    var orangeRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaOr4nge')
    var yellowRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaYellow')
    var greenRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaGreen')
    var blueRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaBlue')
    var purpleRole = messageReaction.message.guild.roles.find(role => role.name === 'eternaPurple')
    var member = messageReaction.message.guild.members.find(member => member.id === user.id)
    if(member.id === client.user.id)return
        switch(roleName)
        {
            case('❤'):
            member.removeRole(redRole)
            break;
            case('📙'):
            member.removeRole(orangeRole)
            break;
            case('💛'):
            member.removeRole(yellowRole)
            break;
            case('💚'):
            member.removeRole(greenRole)
            break;
            case('💙'):
            member.removeRole(blueRole)
            break;
            case('💜'):
            member.removeRole(purpleRole)
            break;
        }
    //console.log(user.username + " reacted with " + roleName) ;
    }
    
})
 });


client.on("message", async msg =>{
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }
    var mention = msg.mentions.users.first()
if (msg.content.startsWith(client.user + "reset")){
    if(msg.member.hasPermission('ADMINISTRATOR')){
    msg.reply("Server settings file updating..");
    setTimeout(settingsReset, 1000);
    function settingsReset(){
    var admin = msg.author.username; 
    var config = {
        changedby: admin,
        profanity: "enabled",
        kill: "enabled",
        prefix: "e.",
        chatbot: "disabled",
        level: "enabled",
        automod: ["disabled", 3, 7, 2000, 7, 15]

    };
        

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
        });
    }}else{if (msg.member.id === "184844321919467520"){
        msg.reply("Server settings file updating..");
        setTimeout(settingsReset, 1000);
        function settingsReset(){
        var admin = msg.author.username; 
        var config = {
            changedby: admin,
            profanity: "enabled",
            kill: "enabled",
            prefix: "e.",
            chatbot: "disabled",
            level: "enabled",
            automod: ["disabled", 3, 7, 2000, 7, 15]
        };
            
    
            fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("File has been created");
            });
        }

        }else{
        msg.reply('You dont have perms.');
    }}
}
var guildid = msg.guild.id;
//chatbot block=================================================================================================
readJson(`./commands/settings/${guildid}`, (err, guildsettings) => {
var mes = msg.content
if (guildsettings.chatbot === "enabled"){
    if(msg.member.id === client.user.id)return
if (msg.content.includes("gay") || msg.content.includes("Gay")){msg.channel.send('No you')}
if(msg.content.endsWith('?')){
    let hmm = Math.floor(Math.random() * 8);
    if (hmm === 3){msg.channel.send('Bro thats kinda a messed up thing to ask smh.')}
    if (hmm === 7){msg.channel.send('hmm...')}
}
if (msg.content.includes('retard')){msg.channel.send('What a clown :clown: ^^^')}
if (msg.content.includes('nigga')){msg.channel.send(`"I'm cool because i say the N word":clown:`)}
if (msg.content.includes('nigger')){msg.channel.send(`Raging racist ^^^ :clown:`)}
if (msg.content.includes('hello') || msg.content.includes('Hello')){
    let hai = Math.floor(Math.random() * 3);
    if (hai === 0){msg.channel.send('Hello there')
    return}
    if (hai === 1){msg.channel.send(`Hiee :smile:`)
    return}
    if (hai === 2){msg.channel.send('Oh hey')
    return}
}
if (msg.content.includes('jew')){msg.channel.send(`Hitler enthusiast ^^`)}
if (mes.includes(`Fuck off Eterna`) || mes.includes(`fuck off Eterna`) || mes.includes(`Fuck off eterna`) || mes.includes(`fuck off eterna`)){msg.channel.send(`You moron I'm a fucking bot.`)}
if (mes.includes('who are you') || mes.includes('Who are you')){msg.channel.send(`Who are ***YOU***??`)}


if (mes.includes('Hail Satan')){msg.channel.send(`

H̷̢̫͈̬͉̝̻̖̥̍̎͆̈́͠ȁ̵̹̲̙̬͍̤̹͓̭̓̍̈́̕ǐ̵̧͔͒̒̈́́́́̌̄̄̅̀͝͝l̷̫͖͈͓̼̦͓̰̱̩̥͕͛̀̀̌̿͑́̉̇́͠ ̵̨̛̯̦̙͔̖̬͇͍̬͚͑̿̂͐̀͜ẗ̸̛̺͎͕͙̭̅͒͝ͅȟ̸̢͔͇̬̙͚̝̟̼͇̯͕̥́͛́̿͝ḛ̴̛̈́̆̈́͗̇̇̏ͅ ̷̻̻͚̠̣̬̜͂̆͊̍͋̂̉̆̿͛̉̕ͅd̷̟̖̱̳̼̫̮͇͙͚̈́̾́̽̔̃̽͗͝͠a̸̢̾̅̉̈́̍̆̍̑̒͆̂̍̚͝ŗ̴̧̡̦͍͚̩̩͍͖͖̥̹̣̏͐k̵̡̩̻̮̬̜͕̥̲̭͚͑̓̋̓̉͝ ̸̢̘̭̬̙̑͆ǒ̸͓̝̟̝̩͖̆̓̏̋̃̌̊̆̄̊̚͘͜͜͜n̷̨͈͍̱̭̜͓̪̩̻̤̣̎̚ͅͅe̸͍͍̩̰͍̻̩̳͔̮̐ͅ`

)}

/*
if (mes.includes('')){msg.channel.send(``)}
if (mes.includes('')){msg.channel.send(``)}
if (mes.includes('')){msg.channel.send(``)}
if (mes.includes('')){msg.channel.send(``)}
if (mes.includes('')){msg.channel.send(``)}
*/

/*
if (mes.includes('')){msg.channel.send(``)}
*/
}
})

//end chatbot block==============================================================================================
//settings block---------------------------------------------------------------------------------
readJson(`./commands/settings/${guildid}`, (err, prfx) => {
    var guildid = msg.guild.id
    const PREFIX = prfx.prefix;
    var mention = msg.mentions.users.first()

    if(mention === client.user){msg.reply(`Forgot the prefix? it's ${PREFIX}`)}
 
    if (msg.author.id === client.user.id) return;
    if (!msg.guild) return;
    if (!msg.content.startsWith(PREFIX)) return;
    if (!msg.member) msg.member = msg.guild.fetchMember(msg);

   const args = msg.content.slice(PREFIX.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();

    if (cmd.length === 0) return;




    
    readJson(`./commands/settings/${guildid}`, (err, curset) => {
var guildid = msg.guild.id;
    if(cmd === 'settingsreset'){
        if(msg.member.hasPermission('ADMINISTRATOR')){
        msg.reply("Server settings file updating..");
        setTimeout(settingsReset, 1000);
        function settingsReset(){
        var admin = msg.author.username; 
            var config = {
                changedby: admin,
                profanity: "enabled",
                kill: "enabled",
                prefix: "e.",
                chatbot: "disabled",
                level: "enabled",
                automod: ["disabled", 3, 7, 2000, 7, 15]
            };
            

            fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("File has been created");
                
        msg.reply("Server settings file updated.");
            });
        }}else{
            msg.reply('You dont have perms.');
        }
    }
    switch(cmd)
    {
        case ('disable'):
            {
                switch(args[0])
            {
                case('profanity'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill
                    var admin = msg.author.username;
                    var pref = curset.prefix
                    var chatbot = curset.chatbot
                    var level = curset.level
                    var automod = curset.automod
                   var color = curset.color
var autorole = curset.autorole
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: "disabled",
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole,
autorole: autorole,
                        color: color,
autorole: autorole
                    };
            
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
            
                }}else{
                    msg.reply('You dont have perms.');
                }

                
                break;}
                case('kill'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var profena = curset.profanity
                    var admin = msg.author.username;
                    var pref = curset.prefix
                    var chatbot = curset.chatbot
                    var level = curset.level
                    var automod = curset.automod
                   var color = curset.color
var autorole = curset.autorole
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: profena,
                        kill: "disabled",
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole,
autorole: autorole,
                        color: color,
autorole: autorole
                    };
            
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
            
                }}else{
                    msg.reply("You dont have perms.");
                }

                
                break;}
                case('chatbot'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = "disabled";
                    var pref = curset.prefix;
                    var level = curset.level
                    var automod = curset.automod
                   var color = curset.color
var autorole = curset.autorole
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole,
autorole: autorole,
                        color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }

                
                break;}
                case('level'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = "disabled"
                    var automod = curset.automod
                   var color = curset.color
var autorole = curset.autorole
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole,
autorole: autorole,
                        color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
                    
                
                break;}
                case('automod'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                   var color = curset.color
var autorole = curset.autorole
                    var automod = ["disabled", 3, 7, 2000, 7, 15]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
                    
                
                break;}
                case('colorrole'):
                    {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                        if(!curset.color || curset.color === 'disabled')return;
                    msg.delete()
                    msg.guild.roles.find(role => role.name === 'eternaRed').delete();
                    msg.guild.roles.find(role => role.name === 'eternaOr4nge').delete();
                    msg.guild.roles.find(role => role.name === 'eternaYellow').delete();
                    msg.guild.roles.find(role => role.name === 'eternaGreen').delete();
                    msg.guild.roles.find(role => role.name === 'eternaBlue').delete();
                    msg.guild.roles.find(role => role.name === 'eternaPurple').delete();
                    var delcolor = curset.color
                    msg.channel.fetchMessage(delcolor).then(msg => msg.delete());
              var killena = curset.kill;
              var botprof = curset.profanity;
              var admin = msg.author.username;
              var chatbot = curset.chatbot;
              var pref = curset.prefix;
              var level = curset.level
              var automod = curset.automod
              var color = 'disabled'
              var autorole = curset.autorole
              setTimeout(botProfanity, 1000); 
              function botProfanity(){
              var config = {
                  changedby: admin,
                  profanity: botprof,
                  kill: killena,
                  prefix: pref,
                  chatbot: chatbot,
                  level: level,
                  automod: automod,
color: color,
autorole: autorole
              };
          
              fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                  if (err) {
                      console.error(err);
                      return;
                  };
                  console.log("File has been created");
              });

          };
                        
                        }else{
                            msg.reply('You dont have perms.');
                        }   
          
                    break;
                }
                case('autorole'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot
                    var pref = curset.prefix;
                    var level = curset.level
                    var automod = curset.automod
                   var color = curset.color
                var autorole = 'disabled'
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
                color: color,
                autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }

                    break;
                }
                case('joinmsg'):
                {
                    if(!msg.member.hasPermission('ADMINISTRATOR')){
                        msg.reply('You dont have perms.')
                        return}
                        var config2 = {
                            id: 'disabled'
                        }
                        fs.writeFile(`./commands/welcome/${guildid}.json`, JSON.stringify(config2, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created")
                            msg.delete()
                            msg.channel.send("Welcome msg disabled.").then(msg => {
                                msg.delete(6000)
                            });
                        });
        
                    break;
                }
            }
                break;
            }
        case ('enable'):
            {
                switch(args[0])
                {
                    case('profanity'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill
                        var admin = msg.author.username;
                        var pref = curset.prefix
                        var chatbot = curset.chatbot
                        var level = curset.level
                        var automod = curset.automod
                      var color = curset.color
var autorole = curset.autorole
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: "enabled",
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod,
color: color,
autorole: autorole
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                    break;
                    }
                    case('kill'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var profena = curset.profanity
                        var admin = msg.author.username;
                        var pref = curset.prefix
                        var chatbot = curset.chatbot
                        var level = curset.level
                        var automod = curset.automod
                       var color = curset.color
var autorole = curset.autorole
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: profena,
                            kill: "enabled",
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod,
color: color,
autorole: autorole
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply("You dont have perms.");
                    }
                        
                    
                
                
                    break;
                
                }
                    case('chatbot'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill;
                       var color = curset.color
var autorole = curset.autorole
                        var botprof = curset.profanity;
                        var admin = msg.author.username;
                        var chatbot = "enabled";
                        var pref = curset.prefix;
                        var level = curset.level
                        var automod = curset.automod
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: botprof,
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod,
color: color,
autorole: autorole
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                        
                    
                    break;
                }
                    case('level'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill;
                        var botprof = curset.profanity;
                        var admin = msg.author.username;
                        var chatbot = curset.chatbot;
                        var pref = curset.prefix;
                       var color = curset.color
var autorole = curset.autorole
                        var level = "enabled"
                        var automod = curset.automod
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: botprof,
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod,
color: color,
autorole: autorole
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                        
                    
                    break;
                }
                    case('automod'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                        var killena = curset.kill;
                        var botprof = curset.profanity;
                       var color = curset.color
var autorole = curset.autorole
                        var admin = msg.author.username;
                        var chatbot = curset.chatbot;
                        var pref = curset.prefix;
                        var level = curset.level
                        var automod = ["enabled", 3, 7, 2000, 7, 15]
                        msg.reply("Server settings file updating..");
                        setTimeout(botProfanity, 1000); 
                        function botProfanity(){
                        var config = {
                            changedby: admin,
                            profanity: botprof,
                            kill: killena,
                            prefix: pref,
                            chatbot: chatbot,
                            level: level,
                            automod: automod,
color: color,
autorole: autorole
                        };
                    
                        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                            if (err) {
                                console.error(err);
                                return;
                            };
                            console.log("File has been created");
                            msg.reply("Server settings file updated!");
                        });
                    
                    }}else{
                        msg.reply('You dont have perms.');
                    }
                        
                    
                    break;
                }
                    case('colorrole'):
                    {
                        if(msg.member.hasPermission('ADMINISTRATOR')){
                            msg.delete();

                            msg.guild.createRole({
                                name: 'eternaRed',
                                color: 'ff0000',
                            })
                            msg.guild.createRole({
                                name: 'eternaOr4nge',
                                color: 'ff8000',
                            })
                            msg.guild.createRole({
                                name: 'eternaYellow',
                                color: 'ffff00',
                            })
                            msg.guild.createRole({
                                name: 'eternaGreen',
                                color: '00ff00',
                            })
                            msg.guild.createRole({
                                name: 'eternaBlue',
                                color: '0000ff',
                            })
                            msg.guild.createRole({
                                name: 'eternaPurple',
                                color: 'ff00ff',
                            })
                            var colorrole = new Discord.RichEmbed()
          .setColor(0xFF0000)
          .addField("Choose a color!", "Red :heart:\n Orange :orange_book:\n Yellow :yellow_heart:\n Green :green_heart:\n Blue :blue_heart:\n Purple :purple_heart:")
          .setThumbnail(msg.guild.iconURL)
          msg.channel.send(colorrole).then(sentMessage => {
              sentMessage.react("❤");
              sentMessage.react("📙");
              sentMessage.react("💛");
              sentMessage.react("💚");
              sentMessage.react("💙");
              sentMessage.react("💜");
              var killena = curset.kill;
              var botprof = curset.profanity;
              var admin = msg.author.username;
              var chatbot = curset.chatbot;
              var pref = curset.prefix;
              var level = curset.level
              var automod = curset.automod
              var color = sentMessage.id
              var autorole = curset.autorole
              setTimeout(botProfanity, 1000); 
              function botProfanity(){
              var config = {
                  changedby: admin,
                  profanity: botprof,
                  kill: killena,
                  prefix: pref,
                  chatbot: chatbot,
                  level: level,
                  automod: automod,
color: color,
autorole: autorole,
              };
          
              fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                  if (err) {
                      console.error(err);
                      return;
                  };
                  console.log("File has been created");
              });

          };
                        
                        })}else{
                            msg.reply('You dont have perms.');
                        }   
          
                    break;
                }
                case('autorole'):
                {
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                        if(!msg.mentions.roles.first()){
                            msg.reply("Mention a role!")
                            return
                        }
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot
                    var pref = curset.prefix;
                    var level = curset.level
                    var automod = curset.automod
                   var color = curset.color
                var autorole = msg.mentions.roles.first().id
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
                color: color,
                autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }

                    break;
                }
                }
               break; 
            }
            
        case('selfrole'):
        {
            if(!msg.member.hasPermission('ADMINISTRATOR')){
                msg.reply('You dont have perms.')
                return
            }
                //args 1-2
                if(!args[0]){
                msg.reply('missing args')
                return}
                msg.delete()
                var role = msg.mentions.roles.first();
                var selfrole = new Discord.RichEmbed()
                .setColor(0xFF0000)
                .addField("Self Role", role)
                msg.channel.send(selfrole).then(react => {
                    react.react('✅');
                    var config2 = {
                        reaction: react.id,
                        role: role.id
                    }
                    fs.writeFile(`./commands/rolemsg/${react.id}.json`, JSON.stringify(config2, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                    });


                })
                
                break;
        }
        case ('prefix'):
        {
                
    if(msg.member.hasPermission('ADMINISTRATOR')){
        if(args < 1){msg.reply('Choose a prefix!')
    return;};
    var killena = curset.kill;
    var botprof = curset.profanity;
    var admin = msg.author.username;
    var chatbot = curset.chatbot
    var pref = args[0];
    var level = curset.level
    var automod = curset.automod
   var color = curset.color
var autorole = curset.autorole
    msg.reply("Server settings file updating..");
    setTimeout(botProfanity, 1000); 
    function botProfanity(){
    var config = {
        changedby: admin,
        profanity: botprof,
        kill: killena,
        prefix: pref,
        chatbot: chatbot,
        level: level,
        automod: automod,
color: color,
autorole: autorole
    };

    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
        if (err) {
            console.error(err);
            return;
        };
        console.log("File has been created");
        msg.reply("Server settings file updated!");
    });

}}else{
    msg.reply('You dont have perms.');
}
    
            break;
        }
        case ('pongnick'):
        {
            msg.reply("Blame asikesa for this command being disabled.")
            if(!msg.member.hasPermission('ADMINISTRATOR'))return;
            /*
            var i = args[1];
            var i2 = 1;
            var user = msg.mentions.members.first()
            while (i2 <= i)
            {
                msg.channel.send("help" + user)
                i2++
            }
            msg.reply('done')*/
        break;
    }
        case ('automod'):
            {
                
    switch(args[0])
    {
        case ('warnat'):
            var arg2 = args[1]
                if(msg.member.hasPermission('ADMINISTRATOR')){
                var killena = curset.kill;
                var botprof = curset.profanity;
                var admin = msg.author.username;
                var chatbot = curset.chatbot;
                var pref = curset.prefix;
                var level = curset.level
               var color = curset.color
var autorole = curset.autorole
                var warnat = arg2
                var banat = curset.automod[2]
                var time = curset.automod[3]
                var maxdupwarn = curset.automod[4]
                var maxdupban = curset.automod[5]
                var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                msg.reply("Server settings file updating..");
                setTimeout(botProfanity, 1000); 
                function botProfanity(){
                var config = {
                    changedby: admin,
                    profanity: botprof,
                    kill: killena,
                    prefix: pref,
                    chatbot: chatbot,
                    level: level,
                    automod: automod,
color: color,
autorole: autorole
                };
            
                fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                    if (err) {
                        console.error(err);
                        return;
                    };
                    console.log("File has been created");
                    msg.reply("Server settings file updated!");
                });
            
            }}else{
                msg.reply('You dont have perms.');
            }
            
            break;
        case ('banat'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                   var color = curset.color
var autorole = curset.autorole
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = arg2
                    var time = curset.automod[3]
                    var maxdupwarn = curset.automod[4]
                    var maxdupban = curset.automod[5]
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        case ('msgtime'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                   var color = curset.color
var autorole = curset.autorole
                    var chatbot = curset.chatbot;
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = curset.automod[2]
                    var time = arg2
                    var maxdupwarn = curset.automod[4]
                    var maxdupban = curset.automod[5]
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        case ('maxdupwarn'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                   var color = curset.color
var autorole = curset.autorole
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = curset.automod[2]
                    var time = curset.automod[3]
                    var maxdupwarn = arg2
                    var maxdupban = curset.automod[5]
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        case ('maxdupban'):
                var arg2 = args[1]
                    if(msg.member.hasPermission('ADMINISTRATOR')){
                    var killena = curset.kill;
                    var botprof = curset.profanity;
                    var admin = msg.author.username;
                    var chatbot = curset.chatbot;
                   var color = curset.color
var autorole = curset.autorole
                    var pref = curset.prefix;
                    var level = curset.level
                    var warnat = curset.automod[1]
                    var banat = curset.automod[2]
                    var time = curset.automod[3]
                    var maxdupwarn = curset.automod[4]
                    var maxdupban = arg2
                    var automod = ["enabled", warnat, banat, time, maxdupwarn, maxdupban]
                    msg.reply("Server settings file updating..");
                    setTimeout(botProfanity, 1000); 
                    function botProfanity(){
                    var config = {
                        changedby: admin,
                        profanity: botprof,
                        kill: killena,
                        prefix: pref,
                        chatbot: chatbot,
                        level: level,
                        automod: automod,
color: color,
autorole: autorole
                    };
                
                    fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        console.log("File has been created");
                        msg.reply("Server settings file updated!");
                    });
                
                }}else{
                    msg.reply('You dont have perms.');
                }
            break;
        default:
            msg.reply("Please enter a setting to change.")
        
    }
            break;
        }
        case('joinmsg'):
        {
            if(!msg.member.hasPermission('ADMINISTRATOR')){
                msg.reply('You dont have perms.')
                return}
            
                var config2 = {
                    id: msg.channel.id,
                    msg: args.join(" ")
                }
                fs.writeFile(`./commands/welcome/${guildid}.json`, JSON.stringify(config2, null, 4), (err) => {
                    if (err) {
                        console.error(err);
                        return;
                    };
                    console.log("File has been created")
                    msg.delete()
                    msg.channel.send("Welcome msg set.").then(msg => {
                        msg.delete(6000)
                    })
                });
            break;
        }
        case('help'):
        {
            var helpmenu = new Discord.RichEmbed()
            .setTitle(`Help Page 1 of 4 (Prefix is ${curset.prefix})`)
            .setColor(0xFF0000)
            .addField('help', `Displays the help menu)`)
            .addField('playerinfo @{user}', 'Displays mentioned user\'s info')
            .addField('info', 'Displays Eterna\'s basic info')
            .addField(`serverinfo`, `Displays basic server information.`)
            .setThumbnail(client.user.avatarURL)
            msg.channel.send(helpmenu).then(sentmsg => {
            
                var config2 = {
                    id: msg.member.id,
                    helpPage: 1
                }
                fs.writeFile(`./commands/helppagetemp/${sentmsg.id}.json`, JSON.stringify(config2, null, 4), (err) => {
                    if (err) {
                        console.error(err);
                        return;
                    };
                    console.log("File has been created")
                    msg.delete()
                })

                sentmsg.react('◀')
                setTimeout(arrow, 500)
                function arrow(){
                sentmsg.react('🏠')}
                setTimeout(arrow2, 1000)
                function arrow2(){
                sentmsg.react('▶')}
                setTimeout(ok, 1500)
                function ok(){
                sentmsg.react('🆗')}
                setTimeout(end, 360000)
                function end(){
                    var helpath = `./commands/helppagetemp/${sentmsg.id}.json`
                    fs.unlink(helpath, (err) => {
                      if (err) {
                        console.error(err)
                        return
                      }
                    
                      //file removed
                    })
                    try{
                    sentmsg.delete()}
                    catch{
                        console.error
                    }

                }
            })
        }
        default:
            return;
    }
//colorroles =================================================================================================

    


//colorroles =============================================================================================
    
})


   
    let command = client.commands.get(cmd);
    if (!command) command = client.commands.get(client.aliases.get(cmd));

    if (command)
        command.run(client, msg, args);
}) 
//end settings block------------------------------------------------------------------------------------
//xp block=======================================================================================================


readJson(`./commands/settings/${guildid}.json`, (err, curset) => {
if (curset.level === 'enabled'){
if (msg){
    if (msg.author.id === client.user.id)return;
    var user = msg.author.id;
    //if xp file doesnt exist, make one========================================
        path = `./commands/usersXP/${user}.json`
        fs.access(path, fs.F_OK, (err) => {
            if (err) {
              console.error(err)
                var userXp = {
                xp: [1,1]
                }
    
    
                fs.writeFile(`./commands/usersXP/${user}.json`, JSON.stringify(userXp, null, 4), (err) => {
                if (err) {
                    console.error(err);
                    return;
                };
                console.log("Xp file has been created");
                });
              return
            }
            //===============================================================
            //file exists: read it and increase xp by 1
            readJson(`./commands/usersXP/${user}.json`, (err, userxpdata) => {
                var xp = userxpdata.xp[0];
                var lvl = userxpdata.xp[1];
                xp++;
                if(xp === (lvl * 5)){
                    lvl++;
                    msg.channel.send(`Congrats ${msg.author.username}! you've reached lvl ${lvl}!`);
                    var userXp = {
                        xp: [0,lvl]
                        }
            
            
                        fs.writeFile(`./commands/usersXP/${user}.json`, JSON.stringify(userXp, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        });
                      return
                }else{
                    var userXp = {
                        xp: [xp,lvl]
                        }
            
            
                        fs.writeFile(`./commands/usersXP/${user}.json`, JSON.stringify(userXp, null, 4), (err) => {
                        if (err) {
                            console.error(err);
                            return;
                        };
                        });
                      return
                }

            
          })

})
}
}
})
//end xp block==================================================================================================
//Automod block=================================================================================================


readJson(`./commands/settings/${guildid}.json`, (err, curset) => {
    if(!curset.automod)return;
if(curset.automod[0] === "enabled"){
    var mod = curset.automod
        
    var AntiSpam = new DiscordAntiSpam({
        warnThreshold: mod[1], // Amount of messages sent in a row that will cause a warning.
        banThreshold: mod[2], // Amount of messages sent in a row that will cause a ban
        maxInterval: mod[3], // Amount of time (in ms) in which messages are cosidered spam.
        warnMessage: "{@user}, Please stop spamming.", // Message will be sent in chat upon warning.
        banMessage: "**{user_tag}** has been banned for spamming.", // Message will be sent in chat upon banning.
        maxDuplicatesWarning: mod[4], // Amount of same messages sent that will be considered as duplicates that will cause a warning.
        maxDuplicatesBan: mod[5], // Amount of same messages sent that will be considered as duplicates that will cause a ban.
        deleteMessagesAfterBanForPastDays: 1, // Amount of days in which old messages will be deleted. (1-7)
        exemptPermissions: ["MANAGE_MESSAGES", "ADMINISTRATOR", "MANAGE_GUILD", "BAN_MEMBERS"], // Bypass users with at least one of these permissions
        ignoreBots: true, // Ignore bot messages
        verbose: true, // Extended Logs from module
        ignoredUsers: [], // Array of string user IDs that are ignored
        ignoredGuilds: [], // Array of string Guild IDs that are ignored
        ignoredChannels: [] // Array of string channels IDs that are ignored
      });
      AntiSpam.on("warnEmit", (member) => console.log(`Attempt to warn ${member.user.tag}.`));
      AntiSpam.on("warnAdd", (member) => console.log(`${member.user.tag} has been warned.`));
      AntiSpam.on("kickEmit", (member) => console.log(`Attempt to kick ${member.user.tag}.`));
      AntiSpam.on("kickAdd", (member) => console.log(`${member.user.tag} has been kicked.`));
      AntiSpam.on("banEmit", (member) => console.log(`Attempt to ban ${member.user.tag}.`));
      AntiSpam.on("banAdd", (member) => console.log(`${member.user.tag} has been banned.`));
      AntiSpam.on("dataReset", () => console.log("Module cache has been cleared."));
      AntiSpam.message(msg);
    }else{return}


})
})







client.on("guildCreate", guild => {
    console.log("Joined a new guild: " + guild.name);
    var guildid = guild.id;
    var admin = guild.owner.username; 
        var config = {
            changedby: admin,
            profanity: "enabled",
            kill: "enabled",
            prefix: "e."
        };
        

        fs.writeFile(`./commands/settings/${guildid}.json`, JSON.stringify(config, null, 4), (err) => {
            if (err) {
                console.error(err);
                return;
            };
            console.log("File has been created");
        });

})



client.on('guildMemberAdd', member =>{
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }
    guildid = member.guild.id
    var path = `./commands/welcome/${guildid}.json`
    fs.access(path, fs.F_OK, (err) => {
        if (err) {
            return
        }
    readJson(`./commands/welcome/${guildid}.json`, (err, curset) => {

    var channel = member.guild.channels.find(channel => channel.id === curset.id);
    if(!channel) return;

    channel.send(member + " " + curset.msg);
    
    })
})
    readJson(`./commands/settings/${guildid}.json`, (err, curset) => {
        if(!curset.autorole)return;
        if(curset.autorole == 'disabled')return
        member.addRole(curset.autorole)
    })
    
});