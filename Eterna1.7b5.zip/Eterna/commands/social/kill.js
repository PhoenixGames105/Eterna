module.exports = {
    name: "kill",
    category: "social",
    description: "does a thing",
    run: async (client, msg, args) => {
        const fs = require('fs')
        var guildid = msg.guild.id
        var readJson = (path, cb) => {
            fs.readFile(require.resolve(path), (err, data) => {
              if (err)
                cb(err)
              else
                cb(null, JSON.parse(data))
            })
          }
        
        readJson(`../settings/${guildid}.json`, (err, settings) => {
        if (settings.kill === "disabled"){return;}else{
        var user = msg.mentions.members.first()
        if (args.length < 1){
            msg.reply("who's getting destroyed?");
            }else{
        if (user){

        var clid = client.user.id
        if (user.id === clid){return}



            if (user.id == msg.author.id){
                msg.reply('You finally end it all. took long enough smh.')
                return;
            }
            let randomKill = Math.floor(Math.random() * 8)
        const sender = msg.author.username;
        const rekt = user;
        if (settings.profanity === 'enabled'){
        switch(randomKill){
            case(0):
            msg.channel.send(`${rekt} gets fucking demolished by ${sender}`);
            break;
            case(1):
            msg.channel.send(`${sender} kicks the stool out from under ${rekt}`);
            break;
            case(2):
            msg.channel.send(`${rekt} gets blue shelled by ${sender}`);
            break;
            case(3):
            msg.channel.send(`${sender} shoves a crystal up ${rekt}'s ass`);
            break;
            case(4):
            msg.channel.send(`${rekt} is killed by ${sender} in a drive by`);
            break;
            case(5):
            msg.channel.send(`${rekt} was given cyanide laced drugs by ${sender}`);
            break;
            case(6):
            msg.channel.send(`${rekt} obtains 28 stab wounds from ${sender}`);
            break;
            case(7):
            msg.channel.send(`${rekt} is thrown to a pack of rabid chipmunks by ${sender}`);
            break;

        }}else{
            switch(randomKill){
                case(0):
                msg.channel.send(`${rekt} gets demolished by ${sender}`);
                break;
                case(1):
                msg.channel.send(`${sender} kicks the stool out from under ${rekt}`);
                break;
                case(2):
                msg.channel.send(`${rekt} gets blue shelled by ${sender}`);
                break;
                case(3):
                msg.channel.send(`${sender} shoves a crystal up ${rekt}'s butt`);
                break;
                case(4):
                msg.channel.send(`${rekt} is killed by ${sender} in a drive by`);
                break;
                case(5):
                msg.channel.send(`${rekt} was given cyanide laced drugs by ${sender}`);
                break;
                case(6):
                msg.channel.send(`${rekt} obtains 28 stab wounds from ${sender}`);
                break;
                case(7):
                msg.channel.send(`${rekt} is thrown to a pack of rabid chipmunks by ${sender}`);
                break;

        }

        }
    }else{msg.reply('User is not in the server')}}


}})}}