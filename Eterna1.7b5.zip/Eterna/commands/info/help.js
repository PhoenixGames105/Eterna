module.exports = {
    name: "helpog",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const fs = require('fs');
        var readJson = (path, cb) => {
            fs.readFile(require.resolve(path), (err, data) => {
              if (err)
                cb(err)
              else
                cb(null, JSON.parse(data))
            })
          }
          var guildid = msg.guild.id;
          readJson(`../settings/${guildid}.json`, (err, settings) => {

        var settings = require(`../settings/${guildid}.json`)
        const PREFIX = settings.prefix;
const Discord = require("discord.js");
if (!args[0] || args[0] === '1'){
const helppage = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(`Help Page (Prefix is ${PREFIX})`)
    .addField('help {2/3/4}', `displays extra help pages(2 for mod cmds, 3 for fun, 4 for settings.)`)
    .addField('playerinfo @{user}', 'Displays your user info')
    .addField('info', 'Displays Eterna\'s basic info')
    .addField(`serverinfo`, `Displays basic server information.`)
    //.addField("roles", "Displays all roles in the server.")
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    
    msg.channel.send(helppage);
}else{if (args[0] === '2'){
const helppage2 = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(`Help Page 2 (Prefix is ${PREFIX})`)
    .addField('ping', 'pong! (requires admin or kick member perms)')
    .addField('purge', 'Deletes messages in bulk (requires admin or manage messages perms)')
    .addField('kick', 'Kicks misbehaving users (requires admin or kick member perms)')
    .addField('ban', 'Bans bad people (requires admin or ban member perms)')
    .addField('automodsettings', `Displays current automod settings and commands.`)
    .addField('mute {@user} {time} {s/m/h/d}', 'Mutes a user for a specified amount of time. If no time is entered the mute is indefinite')
    //.addField(`allinfo`, `Displays all Eterna menus, including help,info,and server settings. (requires admin)`)
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    
    msg.channel.send(helppage2);
    }else{if (args[0] === '3'){
const helppage3 = new Discord.RichEmbed()
    .setColor(0xFF0000)
    .setTitle(`Help Page 3 (Prefix is ${PREFIX})`)
    .addField(`why`, `for all your questions lol`)
    .addField(`kill`, `brutally murder anyone you mention!`)
    .addField(`pat`, `Pat people you like!`)
    .addField(`joinmsg`, `sends a custom message whenever someone joins! (type disable to disable)` )
    .addField('{enable/disable} colorrole', 'Adds some color to your guild! Click the color you want!')
    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    

            msg.channel.send(helppage3);    
    }else{
        if (args[0] === '4'){
            var settingshelp = new Discord.RichEmbed()
        .setColor(0xFF0000)
        .setTitle(` Settings Help Page (Prefix is ${PREFIX})`)
        .addField(`settings`, `Displays your server's current settings.`)
        .addField(`settingsreset`, `Sets settings back to default.`)
        .addField(`{disable/enable} profanity`, `Disables / enables the bot's bad words`)
        .addField(`{disable/enable} kill`, `Disables / enables the kill command`)
        .addField(`prefix {value}`, `Sets the Bot's prefix.`)
        .addField(`{enable/disable} chatbot`, "Enables/Disables the chatbot responses.")
        .addField(`{enable/disable} level`, "Enables/Disables chat based level ups.")
        .addField(`{enable/disable} automod`, "Enables/Disables AutoMod function.")
        .addField("{enable/disable} autorole {@role}", "Gives user a specified role upon joining the server")
        .addField("selfrole {@role}", "Lets users choose a role via reaction")
        .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
    
        msg.channel.send(settingshelp);
        

        }else{return;
        if (args[0] === 'all'){
        const helppage3 = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setTitle(`Help Page 3 (Prefix is ${PREFIX})`)
            .addField(`why`, `for all your questions lol`)
            .addField(`kill`, `brutally murder anyone you mention!`)
            .addField(`pat`, `Pat people you like!`)
            .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
            const helppage2 = new Discord.RichEmbed()
                .setColor(0xFF0000)
                .setTitle(`Help Page 2 (Prefix is ${PREFIX})`)
                .addField('ping', 'pong! (requires admin or kick member perms)')
                .addField('purge', 'Deletes messages in bulk (requires admin or manage messages perms)')
                .addField('kick', 'Kicks misbehaving users (requires admin or kick member perms)')
                .addField('ban', 'Bans bad people (requires admin or ban member perms)')
                .addField('mute {@user} {time} {s/m/h/d}', 'Mutes a user for a specified amount of time. If no time is entered the mute is indefinite')
                .addField('helpsettings', 'Displays the settings help menu')
                .addField('automodsettings', `Displays current automod settings and commands.`)
                .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
                const helppage = new Discord.RichEmbed()
                    .setColor(0xFF0000)
                    .setTitle(`Help Page (Prefix is ${PREFIX})`)
                    .addField('help {2/3}', `displays extra help pages`)
                    .addField('playerinfo', 'Displays your user info')
                    .addField('info', 'Displays Eterna\'s basic info')
                    .addField(`serverinfo`, `Displays basic server information.`)
                    //.addField("roles", "Displays all roles in the server.")
                    .setThumbnail('https://github.com/PhoenixGames105/Eterna/blob/master/eterna%20(2).jpg?raw=true')
        msg.channel.send(helppage)
        msg.channel.send(helppage2)
        msg.channel.send(helppage3)
        return;
    
    }
}
    }}}})
}}