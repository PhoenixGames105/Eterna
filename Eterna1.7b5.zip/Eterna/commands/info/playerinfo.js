module.exports = {
    name: "playerinfo",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
      
      if(args.length < 1) return msg.reply('Please mention someone.')
        const Discord = require("discord.js");
        const fs = require('fs')
        var readJson = (path, cb) => {
            fs.readFile(require.resolve(path), (err, data) => {
              if (err)
                cb(err)
              else
                cb(null, JSON.parse(data))
            })
          }
          var userx = msg.mentions.members.first()
          var user = userx
          if(!user) return msg.reply("User is not in this server.")
          
          
          path = `./commands/usersXP/${user.id}.json`
          fs.access(path, fs.F_OK, (err) => {
              if (err) {
                console.error(err)
                  var userXp = {
                  xp: [1,1]
                  }
      
      
                  fs.writeFile(`./commands/usersXP/${user.id}.json`, JSON.stringify(userXp, null, 4), (err) => {
                  if (err) {
                      console.error(err);
                      return;
                  };
                  console.log("Xp file has been created");
                  });
                }
              })


          readJson(`../usersXP/${user.id}.json`, (err, guildsettings) => {
            var level = guildsettings.xp[1]
            var xp = guildsettings.xp[0]
            var maxp = level * 5
const playerinfo = new Discord.RichEmbed()
            .setColor(0xFF0000)
            .setThumbnail(user.user.avatarURL)
            .setTitle('Player Info')
            .addField('Player Name ', user.user.username)
            //.addField('Current Server', msg.guild.name)
            .addField('Status ', user.user.presence.status)
            .addField(`Join date`, user.user.createdAt)
            .addField('Level', level + ` | XP: ${xp} / ${maxp}`)
            msg.channel.send(playerinfo);
          })
}}