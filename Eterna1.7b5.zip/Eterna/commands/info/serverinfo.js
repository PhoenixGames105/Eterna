module.exports = {
    name: "serverinfo",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
const Discord = require("discord.js");
const serverinfo = new Discord.RichEmbed()
.setColor(0xFF0000)
.setTitle("Server Info")
.setThumbnail(msg.guild.iconURL)
.addField("Server Name ", msg.guild.name)
.addField("Owner ", msg.guild.owner)
.addField("Member Count", msg.guild.memberCount)
.addField("Created", msg.guild.createdAt)
.addField("Region", msg.guild.region)
msg.channel.send(serverinfo);
    }}