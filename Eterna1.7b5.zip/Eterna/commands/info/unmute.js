module.exports = {
    name: "unmute",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const channels = msg.guild.channels;
        
        if(!msg.member.hasPermission('MANAGE_ROLES')) return msg.reply('You dont have perms')
        if(args.length < 1) return msg.reply('Please mention someone to unmute.')
        var userx = msg.mentions.members.first()
        var user = userx
        if(!user) return msg.reply("User is not in this server.")

            for (let [, channel] of channels) {
            channel.overwritePermissions(msg.mentions.users.first(), { SEND_MESSAGES: null })
              .catch(console.error);
          }
          msg.channel.send(`Unmuted ${msg.mentions.users.first().username}.`)
        
    }
}
