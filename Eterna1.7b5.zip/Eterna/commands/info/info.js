module.exports = {
    name: "info",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        const Discord = require('discord.js')
        var version = '1.7b5 | Released 11/15/19 @ 7:31pm';
        var icon = client.user.avatarURL    
        var infotable = new Discord.RichEmbed()
        .setColor(0xFF0000)
        .setTitle(`Eterna Info`)
        .setThumbnail(icon)
        .addField(`Version`, version)
        .addField('Invite me to your server!', "[<<Invite>>](https://discordapp.com/oauth2/authorize?client_id=607007761947033601&scope=bot&permissions=2146958839)")
        .addField('Join the EternaBot Development discord!', '[<<Join>>](https://discord.gg/SxUVCzn)')


        
            msg.channel.send(infotable);
            return;
        
    }}