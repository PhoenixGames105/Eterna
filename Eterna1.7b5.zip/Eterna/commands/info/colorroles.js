module.exports = {
    name: "colorroles",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        
        const fs = require('fs');
        const Discord = require('discord.js')
    var readJson = (path, cb) => {
        fs.readFile(require.resolve(path), (err, data) => {
          if (err)
            cb(err)
          else
            cb(null, JSON.parse(data))
        })
      }
          var colorrole = new Discord.RichEmbed()
        .setColor(0xFF0000)
        .addField("Choose a color!", "Red :heart:\n Orange :orange_book:\n Yellow :yellow_heart:\n Green :green_heart:\n Blue :blue_heart:\n Purple :purple_heart:")
        .setThumbnail(msg.guild.iconURL)
        msg.channel.send(colorrole).then(sentMessage => {
            sentMessage.react("❤");
            sentMessage.react("📙");
            sentMessage.react("💛");
            sentMessage.react("💚");
            sentMessage.react("💙");
            sentMessage.react("💜");
            msg.channel.send(sentMessage.id);
        });



    }
}