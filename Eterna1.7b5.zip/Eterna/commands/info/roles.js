module.exports = {
    name: "roles",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
const Discord = require("discord.js");
const roleinfo = new Discord.RichEmbed()
.setTitle("Roles in " + msg.guild.name)
.setColor(0xFF0000)
.addField("RolesTBC", msg.guild.roles)
msg.channel.send(roleinfo);
    }}