module.exports = {
    name: "mute",
    category: "info",
    description: "does a thing",
    run: async (client, msg, args) => {
        var timer = args[1]
        var set = args[1]
        const channels = msg.guild.channels;
        var unit
        var timer2
        
        if(!msg.member.hasPermission('MANAGE_ROLES')) return msg.reply('You dont have perms')
        if(args.length < 1) return msg.reply('Please mention someone to SILENCE.')
        var userx = msg.mentions.members.first()
        var user = userx
        if(!user) return msg.reply("User is not in this server.")
        //if(!args[1]) return msg.reply("Please give an amount of time to mute.")
        

        if(msg.content.endsWith('m')){
            timer2 = set
            timer = timer * 60
            unit = 'minutes'
        }else if(msg.content.endsWith('h')){
            timer2 = set
            timer = timer * 60 * 60
            unit = 'hours'
        }else if(msg.content.endsWith('d')){
            timer2 = set
            timer = timer2 * 60 * 60 * 24
            unit = 'days'
        }else if(msg.content.endsWith('s')){
            timer2 = set
            unit = 'seconds'
        }else{
            for (let [, channel] of channels) {
                channel.overwritePermissions(msg.mentions.users.first(), { SEND_MESSAGES: false })
                  .catch(console.error);
              }
            msg.channel.send(`Muted ${msg.mentions.users.first().username} Indefinitely.`)
            return;
        }
        for (let [, channel] of channels) {
          channel.overwritePermissions(msg.mentions.users.first(), { SEND_MESSAGES: false })
            .catch(console.error);
        }
        msg.reply(`Muted ${msg.mentions.users.first().username} for ${timer2} ${unit}`)

        setTimeout(unmute, timer * 1000);

        function unmute()
        {
            for (let [, channel] of channels) {
            channel.overwritePermissions(msg.mentions.users.first(), { SEND_MESSAGES: null })
              .catch(console.error);
          }
          msg.channel.send(`Unmuted ${msg.mentions.users.first().username}.`)
        }
    }
}
